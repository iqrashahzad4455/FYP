import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:rockingequestrian/Home_Screen.dart';
import 'package:rockingequestrian/database/user_database.dart';
import 'package:rockingequestrian/functions/user_server/user_server.dart';
import 'package:rockingequestrian/meta/theme_meta.dart';
import 'package:rockingequestrian/signup_screen.dart';
import 'package:rockingequestrian/types/login_response.dart';
import 'package:rockingequestrian/utils/snackbar_utils.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController email = TextEditingController();
  final TextEditingController password = TextEditingController();

  final UserDatabase userDB = UserDatabase.instance;

  @override
  void dispose() {
    email.dispose();
    password.dispose();
    super.dispose();
  }

  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      return autoLogin();
    });
    super.initState();
  }

  void autoLogin() {
    final String? uid = userDB.getUID;
    final String? pwd = userDB.getPWD;
    if (uid != null && pwd != null) {
      if (uid.isNotEmpty && pwd.isNotEmpty) {
        email.text = uid;
        password.text = pwd;
        return login();
      }
    }
  }

  /// Login user
  void login() async {
    if (email.text.isEmpty) {
      return showSnackbar(context: context, message: "Enter your email");
    } else if (password.text.isEmpty) {
      return showSnackbar(context: context, message: "Enter your Password");
    }
    return UserServer()
        .login(email: email.text, password: password.text)
        .then((res) async {
      showSnackbar(context: context, message: res.name);
      // if response is equal to success then move to dashboard
      if (res == LoginResponse.success) {
        // Move to Dashboard
        return Navigator.pushAndRemoveUntil<void>(
          context,
          CupertinoPageRoute(builder: (_) => const HomeScreen()),
          (_) => false,
        );
      }
      return;
    });
  }

  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.of(context).size;
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: AppTheme.brownBG,
      child: Scaffold(
        backgroundColor: Colors.blue,
        body: SafeArea(
          child: SizedBox(
            width: size.width,
            height: size.height,
            child: SingleChildScrollView(
              clipBehavior: Clip.antiAliasWithSaveLayer,
              physics: const AlwaysScrollableScrollPhysics(),
              padding: EdgeInsets.symmetric(horizontal: size.width * 0.06),
              child: Column(
                children: [
                  SizedBox(height: size.height * 0.125),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(90),
                    child: Image.asset(
                      "images/logo.png",
                      height: size.height * 0.2,
                      width: size.height * 0.2,
                      fit: BoxFit.cover,
                    ),
                  ),
                  SizedBox(height: size.height * 0.06),
                  TextField(
                    controller: email,
                    decoration: InputDecoration(
                      hoverColor: Colors.teal,
                      fillColor: Colors.white,
                      filled: true,
                      hintText: "Enter Your Email",
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  ),
                  SizedBox(height: size.height * 0.01),
                  TextField(
                    controller: password,
                    decoration: InputDecoration(
                      hoverColor: Colors.white,
                      fillColor: Colors.white,
                      filled: true,
                      hintText: "Enter Your Password",
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  ),
                  SizedBox(height: size.height * 0.025),
                  MaterialButton(
                    height: 52,
                    minWidth: size.width,
                    color: Colors.white,
                    clipBehavior: Clip.antiAliasWithSaveLayer,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    child: const Text(
                      "Log ln",
                      textAlign: TextAlign.center,
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    onPressed: () => login(),
                  ),
                  SizedBox(height: size.height * 0.03),
                  const Text(
                    "Do not have an account?,",
                    textAlign: TextAlign.center,
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: size.height * 0.03),
                  OutlinedButton(
                    style: ButtonStyle(
                      minimumSize: MaterialStateProperty.all<Size>(
                        Size(size.width, 55),
                      ),
                      backgroundColor: MaterialStateProperty.all(Colors.white),
                      side: MaterialStateProperty.all(
                        const BorderSide(color: Colors.white),
                      ),
                      shape: MaterialStateProperty.all(
                        RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10.0),
                        ),
                      ),
                    ),
                    child: const Text(
                      "Sign-up",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    onPressed: () {
                      Navigator.push<void>(
                        context,
                        CupertinoPageRoute(
                          builder: (_) => const SignUpScreen(),
                        ),
                      );
                    },
                  ),
                  SizedBox(height: size.height * 0.03),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Text(
                        "About Us",
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      SizedBox(width: size.width * 0.1),
                      const Text(
                        "Contact Us",
                        style: TextStyle(fontWeight: FontWeight.bold),
                      )
                    ],
                  ),
                  SizedBox(height: size.height * 0.03),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
