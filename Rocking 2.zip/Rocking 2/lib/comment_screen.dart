import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:comment_box/comment/comment.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:rockingequestrian/functions/models/post_model.dart';
import 'package:rockingequestrian/provider/user_provider.dart';

class TestMe extends StatefulWidget {
  PostModel post;

  TestMe({
    Key? key,
    required this.post,
  });
  @override
  _TestMeState createState() => _TestMeState();
}

class _TestMeState extends State<TestMe> {
  final formKey = GlobalKey<FormState>();
  final TextEditingController commentController = TextEditingController();
  List filedata = [
    // {
    //   'name': 'Asif',
    //   'pic': 'images/logo1.jpg',
    //   'message': 'I love to code',
    //   'date': '2021-01-01 12:00:00'
    // },
  ];
  late final UserProvider provider;

  @override
  void initState() {
    provider = context.read<UserProvider>();

    super.initState();
  }

  // {
  //   'name': 'Asif',
  //   'pic': 'images/logo1.jpg',
  //   'message': 'I love to code',
  //   'date': '2021-01-01 12:00:00'
  // },

  // Widget commentChild(data) {
  //   return ListView(
  //     children: [
  //       for (var i = 0; i < data.length; i++)
  //         Padding(
  //           padding: const EdgeInsets.fromLTRB(2.0, 8.0, 2.0, 0.0),
  //           child: ListTile(
  //             leading: GestureDetector(
  //               onTap: () async {
  //                 // Display the image in large form.
  //                 print("Comment Clicked");
  //               },
  //               child: Container(
  //                 height: 50.0,
  //                 width: 50.0,
  //                 decoration: new BoxDecoration(
  //                     color: Colors.blue,
  //                     borderRadius: new BorderRadius.all(Radius.circular(50))),
  //                 child: CircleAvatar(
  //                     radius: 50,
  //                     backgroundImage: CommentBox.commentImageParser(
  //                         imageURLorPath: data[i]['pic'])),
  //               ),
  //             ),
  //             title: Text(
  //               data[i]['name'],
  //               style: TextStyle(fontWeight: FontWeight.bold),
  //             ),
  //             subtitle: Text(data[i]['message']),
  //             trailing: Text(data[i]['date'], style: TextStyle(fontSize: 10)),
  //           ),
  //         )
  //     ],
  //   );
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text("Comment Page"),
        backgroundColor: Colors.blue,
      ),
      body: Container(
        child: CommentBox(
          userImage:
              CommentBox.commentImageParser(imageURLorPath: "images/logo.png"),
          labelText: 'Write a comment...',
          errorText: 'Comment cannot be blank',
          withBorder: false,
          sendButtonMethod: () async {
            if (formKey.currentState!.validate()) {
              FirebaseFirestore.instance
                  .collection('comments/${widget.post.postID}/comments')
                  .doc()
                  .set({
                'name': provider.user.name,
                'email': provider.user.email,
                'message': commentController.text,
                'date': Timestamp.now(),
              });
              commentController.clear();
              FocusScope.of(context).unfocus();
            } else {
              print("Not validated");
            }
          },
          formKey: formKey,
          commentController: commentController,
          backgroundColor: Colors.white,
          textColor: Colors.black,
          sendWidget:
              const Icon(Icons.send_sharp, size: 30, color: Colors.black),
          child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('comments/${widget.post.postID}/comments')
                  .snapshots(),
              builder: (context, snapshot) {
                var data = snapshot.data;

                if (!snapshot.hasData) {
                  return const Center(
                    child: CircularProgressIndicator(
                      color: Colors.black,
                    ),
                  );
                }
                if (snapshot.data!.docs.isEmpty) {
                  return const Center(child: Text('No Comments added yet'));
                }

                return ListView.builder(
                    physics: const NeverScrollableScrollPhysics(),
                    shrinkWrap: true,
                    scrollDirection: Axis.vertical,
                    itemCount: data?.docs.length,
                    itemBuilder: (_, i) {
                      Timestamp date = data!.docs[i]['date'];
                      return ListTile(
                        leading: GestureDetector(
                          onTap: () async {
                            // Display the image in large form.
                            print("Comment Clicked");
                          },
                          child: Container(
                            height: 50.0,
                            width: 50.0,
                            decoration: const BoxDecoration(
                                color: Colors.blue,
                                borderRadius:
                                    BorderRadius.all(Radius.circular(50))),
                            child: CircleAvatar(
                                radius: 50,
                                backgroundImage: CommentBox.commentImageParser(
                                    imageURLorPath: 'images/logo.png')),
                          ),
                        ),
                        title: Text(
                          data.docs[i]['name'] ?? '',
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                        subtitle: Text(data.docs[i]['message'] ?? ''),
                        trailing: Text(date.toDate().toString(),
                            style: const TextStyle(fontSize: 10)),
                      );
                    });
              }),
        ),
      ),
    );
  }
}
