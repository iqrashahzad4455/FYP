import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

@immutable
abstract class AppTheme {
  const AppTheme._();

  static SystemUiOverlayStyle whiteBG = SystemUiOverlayStyle.dark.copyWith(
    statusBarColor: Colors.white,
    statusBarBrightness: Brightness.light,
    statusBarIconBrightness: Brightness.dark,
    systemNavigationBarColor: Colors.white,
    systemNavigationBarIconBrightness: Brightness.dark,
  );

  static SystemUiOverlayStyle brownBG = SystemUiOverlayStyle.dark.copyWith(
    statusBarColor: Colors.brown,
    statusBarBrightness: Brightness.dark,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: Colors.brown,
    systemNavigationBarIconBrightness: Brightness.light,
  );
}
