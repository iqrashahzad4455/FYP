import 'package:flutter/material.dart';

@immutable
abstract class AppSettings {
  const AppSettings._();

  static const String appName = "Rocking Equestrian";
}
