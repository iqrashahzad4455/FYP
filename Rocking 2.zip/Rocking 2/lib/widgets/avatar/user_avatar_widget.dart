import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

class UserAvatar extends StatelessWidget {
  final String? url;
  final double? height, width;
  const UserAvatar({super.key, this.url, this.height, this.width});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width ?? defaultWidth,
      height: height ?? defaultHeight,
      clipBehavior: Clip.antiAliasWithSaveLayer,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        image: DecorationImage(
          fit: BoxFit.cover,
          image: AssetImage(dummyAvatar),
        ),
      ),
      child: url != null && url!.isNotEmpty
          ? ClipOval(
              clipBehavior: Clip.antiAliasWithSaveLayer,
              child: CachedNetworkImage(
                imageUrl: url!,
                fit: BoxFit.cover,
                width: width ?? defaultWidth,
                height: height ?? defaultHeight,
                placeholder: (_, __) => placeHolder,
                errorWidget: (_, __, ___) => placeHolder,
              ),
            )
          : placeHolder,
    );
  }

  String get dummyAvatar {
    return "images/person3.jpeg";
  }

  Widget get placeHolder {
    return Image.asset(
      dummyAvatar,
      fit: BoxFit.cover,
      width: width ?? defaultWidth,
      height: height ?? defaultHeight,
    );
  }

  /// Default Height and Width
  double get defaultWidth => 80;
  double get defaultHeight => 80;
}
