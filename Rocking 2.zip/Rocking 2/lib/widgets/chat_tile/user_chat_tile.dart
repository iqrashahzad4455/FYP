import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../chatpage.dart';
import '../../functions/models/user_model.dart';

class UserChatTile extends StatelessWidget {
  final UserModel mode;
  const UserChatTile({super.key, required this.mode});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        Navigator.push<void>(
          context,
          CupertinoPageRoute(builder: (_) => ChatPage(user: mode)),
        );
        return;
      },
      child: Container(
        margin: const EdgeInsets.symmetric(
          vertical: 12,
        ),
        child: Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(40),
              child: Image.asset(
                "images/logo3.jpg",
                fit: BoxFit.cover,
                height: 61,
                width: 60,
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    mode.name,
                    style: const TextStyle(
                        fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    "  Click to start chat",
                    style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w500,
                        color: Colors.black54),
                  ),
                ],
              ),
            ),
            const Spacer(),
            const Text(
              "10:11",
              style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w500,
                color: Colors.brown,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
