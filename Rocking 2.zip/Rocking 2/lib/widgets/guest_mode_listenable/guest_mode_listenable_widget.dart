import 'package:flutter/material.dart';
import 'package:get_storage/get_storage.dart';

class GuestModeListenable extends StatelessWidget {
  final ValueStorage<Map<String, dynamic>> listenable;
  final Widget Function(Map<String, dynamic>? data) child;
  final Widget Function(Map<String, dynamic>? data)? guest;
  const GuestModeListenable({
    super.key,
    this.guest,
    required this.child,
    required this.listenable,
  });

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<Map<String, dynamic>?>(
      valueListenable: listenable,
      builder: (_, Map<String, dynamic>? d, __) {
        if (d != null && d.isNotEmpty) {
          return child(d);
        } else if (guest != null) {
          return guest!(d);
        } else {
          return child(d);
        }
      },
    );
  }
}
