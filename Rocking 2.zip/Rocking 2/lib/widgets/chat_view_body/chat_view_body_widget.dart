import 'package:flutter/material.dart';
import 'package:rockingequestrian/functions/models/user_model.dart';
import 'package:rockingequestrian/widgets/chat_tile/user_chat_tile.dart';

class ChatViewBody extends StatelessWidget {
  final List<UserModel>? users;
  const ChatViewBody({super.key, required this.users});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: users?.length ?? 0,
      clipBehavior: Clip.antiAliasWithSaveLayer,
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.symmetric(
        vertical: 5,
        horizontal: 15,
      ),
      itemBuilder: (_, int i) => UserChatTile(mode: users![i]),
    );
  }
}
