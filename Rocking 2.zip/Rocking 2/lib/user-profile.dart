import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:rockingequestrian/Home_Screen.dart';
import 'package:rockingequestrian/chatpage.dart';
import 'package:rockingequestrian/database/user_database.dart';
import 'package:rockingequestrian/functions/extensions/string/string.extensions.fucntions.dart';
import 'package:rockingequestrian/functions/models/post_model.dart';
import 'package:rockingequestrian/functions/models/user_model.dart';
import 'package:rockingequestrian/functions/user_server/user_server.dart';
import 'package:rockingequestrian/provider/user_provider.dart';
import 'package:rockingequestrian/utils/snackbar_utils.dart';
import 'package:rockingequestrian/widgets/avatar/user_avatar_widget.dart';
import 'package:share/share.dart';

class UserProfileView extends StatefulWidget {
  final UserModel user;
  const UserProfileView({super.key, required this.user});

  @override
  State<UserProfileView> createState() => _UserProfileViewState();
}

class _UserProfileViewState extends State<UserProfileView> {
  /// Create an Instance of `StreamSubscription<UserModel>`
  late final StreamSubscription<UserModel> userStreamSub;

  /// Create an Instance of `UserModel` to Hold user details
  final StreamController<UserModel> _user =
      StreamController<UserModel>.broadcast();

  /// Update `_user` stream value
  void updateUserStream(UserModel event) {
    // Make sure stream is not closed
    if (!_user.isClosed) {
      _user.sink.add(event);
    }
    return;
  }

  /// Create an Instance of `UserDatabase`
  late final UserDatabase _userDB;

  /// Create an Instance of `UserServer`
  late final UserServer _userServer;

  @override
  void initState() {
    // Initialize `UserServer`
    _userServer = UserServer();
    // Initialize `UserModel` and `StreamSubscription`
    userStreamSub = _userServer
        .getUserById(widget.user.email.nullSafe)
        .listen((UserModel event) {
      updateUserStream(event);
    });
    // Initialize `UserDatabase`
    _userDB = UserDatabase.instance;
    super.initState();
  }

  @override
  void dispose() {
    _user.close();
    userStreamSub.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        elevation: 0,
        actions: [
          PopupMenuButton(
            itemBuilder: (context) => [
              PopupMenuItem(
                child: const Text("Share Profile"),
                onTap: () {
                  Share.share(
                    "https://play.google.com/store/app/details?id=com.instructivetech.testapp",
                  );
                },
              ),
            ],
          ),
        ],
        backgroundColor: Colors.blue,
        title: StreamBuilder<UserModel>(
          stream: _user.stream,
          initialData: widget.user,
          builder: (_, AsyncSnapshot<UserModel> snap) {
            return Text(
              snap.data?.name ?? widget.user.name,
              style: const TextStyle(color: Colors.black),
            );
          },
        ),
      ),
      body: SizedBox(
        width: size.width,
        height: size.height,
        child: Column(
          children: [
            SizedBox(height: size.height * 0.03),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: size.width * 0.04),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  StreamBuilder<UserModel>(
                    stream: _user.stream,
                    initialData: widget.user,
                    builder: (_, AsyncSnapshot<UserModel> snap) {
                      return UserAvatar(
                        width: 90,
                        height: 90,
                        url: snap.data?.profileUrl ?? widget.user.profileUrl,
                      );
                    },
                  ),
                  Expanded(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        StreamBuilder<UserModel>(
                          stream: _user.stream,
                          initialData: widget.user,
                          builder: (_, AsyncSnapshot<UserModel> s) {
                            return Text(
                              textAlign: TextAlign.center,
                              (s.data?.followersList.length ?? 0).toString(),
                              style: const TextStyle(
                                fontSize: 24,
                                fontWeight: FontWeight.bold,
                              ),
                            );
                          },
                        ),
                        const SizedBox(height: 4),
                        const Text(
                          "Followers",
                          textAlign: TextAlign.center,
                          style: TextStyle(fontSize: 12),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        StreamBuilder<UserModel>(
                          stream: _user.stream,
                          initialData: widget.user,
                          builder: (_, AsyncSnapshot<UserModel> s) {
                            return Text(
                              textAlign: TextAlign.center,
                              (s.data?.followingList.length ?? 0).toString(),
                              style: const TextStyle(
                                fontSize: 24,
                                fontWeight: FontWeight.bold,
                              ),
                            );
                          },
                        ),
                        const SizedBox(height: 4),
                        const Text(
                          "Following",
                          textAlign: TextAlign.center,
                          style: TextStyle(fontSize: 12),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: size.height * 0.015),
            SizedBox(
              width: size.width * 0.88,
              child: StreamBuilder<UserModel>(
                stream: _user.stream,
                initialData: widget.user,
                builder: (_, AsyncSnapshot<UserModel> s) {
                  return Text(
                    textAlign: TextAlign.start,
                    style: const TextStyle(fontSize: 16),
                    s.data?.bio ?? widget.user.bio ?? "Bio not available",
                  );
                },
              ),
            ),
            SizedBox(height: size.height * 0.015),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: size.width * 0.04),
              child: Row(
                children: [
                  if (!_userDB.getUID.isSame(widget.user.email))
                    Expanded(child: Consumer<UserProvider>(
                      builder: (_, UserProvider pro, __) {
                        return StreamBuilder<UserModel>(
                          stream: _user.stream,
                          initialData: widget.user,
                          builder: (_, AsyncSnapshot<UserModel> s) {
                            // Check if user is already following this or not
                            final bool isFollowing = pro.user.followingList
                                .contains(widget.user.email);
                            return MaterialButton(
                              height: 50,
                              color: Colors.blue,
                              textColor: Colors.white,
                              shape: const StadiumBorder(),
                              onPressed: () {
                                if (s.data == null) {
                                  return showSnackbar(
                                    context: context,
                                    message: "Action not allowed",
                                  );
                                } else if (isFollowing) {
                                  _userServer.unFollow(
                                    user: s.data!,
                                    context: context,
                                  );
                                  return;
                                } else {
                                  _userServer.follow(
                                    user: s.data!,
                                    context: context,
                                  );
                                  return;
                                }
                              },
                              child: Text(isFollowing ? "unFollow" : "Follow"),
                            );
                          },
                        );
                      },
                    )),
                  if (!_userDB.getUID.isSame(widget.user.email))
                    SizedBox(width: size.width * 0.02),
                  Expanded(
                    child: MaterialButton(
                      height: 50,
                      color: Colors.blue,
                      textColor: Colors.white,
                      shape: const StadiumBorder(),
                      onPressed: () async {
                        return Navigator.push<void>(
                          context,
                          CupertinoPageRoute(
                            builder: (_) => ChatPage(user: widget.user),
                          ),
                        );
                      },
                      child: const Text("Message"),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: size.height * 0.03),
            Expanded(
              child: StreamBuilder<List<PostModel>>(
                stream: context
                    .read<UserProvider>()
                    .postServer
                    .getPostsByUser(widget.user.email),
                builder: (_, AsyncSnapshot<List<PostModel>> s) {
                  // Check if data is available
                  if (s.hasData && s.data != null && s.data!.isNotEmpty) {
                    return ListView.builder(
                      padding: EdgeInsets.zero,
                      itemCount: (s.data?.length ?? 0),
                      physics: const BouncingScrollPhysics(),
                      clipBehavior: Clip.antiAliasWithSaveLayer,
                      itemBuilder: (_, int index) {
                        return ClubCard(
                          post: s.data![index],
                          enableProfileTab: false,
                        );
                      },
                    );
                  }
                  // Check if Stream is Connected then check data
                  if (s.connectionState == ConnectionState.active) {
                    // show no data available
                    return Center(
                      child: Text(
                        "Posts not available",
                        textAlign: TextAlign.end,
                        style: TextStyle(
                          fontSize: 16,
                          color: Colors.black.withOpacity(0.75),
                        ),
                      ),
                    );
                  } else {
                    // show a loading indicator
                    return const Center(
                      child: CircularProgressIndicator.adaptive(),
                    );
                  }
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
