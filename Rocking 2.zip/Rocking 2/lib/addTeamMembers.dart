import 'dart:math';
import 'dart:ui';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:rockingequestrian/Home_Screen.dart';

import 'package:rockingequestrian/provider/user_provider.dart';
import 'package:rockingequestrian/utils/snackbar_utils.dart';

class AddTeamMember extends StatefulWidget {
  final String teamName;
  final String captain;
  final String members;
  final String address;
  final String eventID;
  const AddTeamMember({
    super.key,
    required this.address,
    required this.eventID,
    required this.captain,
    required this.members,
    required this.teamName,
  });

  @override
  State<AddTeamMember> createState() => _AddTeamMemberState();
}

class _AddTeamMemberState extends State<AddTeamMember> {
  final TextEditingController _riderName = TextEditingController();
  final TextEditingController _horseName = TextEditingController();
  final TextEditingController _age = TextEditingController();

  @override
  void initState() {
    super.initState();
    final random = Random();
    const availableChars =
        'AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz1234567890';
    final userID = List.generate(16,
            (index) => availableChars[random.nextInt(availableChars.length)])
        .join();
    setState(() {
      docId = userID;
    });
    print(docId);
  }

  @override
  void dispose() {
    super.dispose();
  }

  bool addedTeam = false;

  final List<String> _items = ['International', 'National'];
  String? _selectedItem = 'National';
  String docId = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.blue,
        title: const Text("Event Form"),
      ),
      body: SingleChildScrollView(
        clipBehavior: Clip.antiAliasWithSaveLayer,
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.symmetric(horizontal: 30),
        child: Column(
          children: [
            const SizedBox(height: 20),
            const Text(
              "Add Team Member",
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.w600,
                decoration: TextDecoration.underline,
              ),
            ),
            const SizedBox(height: 10),
            FormTextField(hint: "Rider Name", controller: _riderName),
            const SizedBox(height: 6),
            FormTextField(hint: "Horse Name", controller: _horseName),
            const SizedBox(height: 6),
            FormTextField(hint: "Age", controller: _age),
            const SizedBox(height: 6),
            Container(
              color: Colors.white,
              child: Padding(
                padding: const EdgeInsets.all(0.0),
                child: DropdownButton<String>(
                  value: _selectedItem,
                  items: _items.map((item) {
                    return DropdownMenuItem<String>(
                      value: item,
                      child: Text(item),
                    );
                  }).toList(),
                  onChanged: (value) {
                    setState(() {
                      _selectedItem = value;
                    });
                  },
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: InkWell(
                onTap: () async {
                  if (_riderName.text.isEmpty) {
                    return showSnackbar(
                      context: context,
                      message: "Type Rider Name",
                    );
                  } else if (_horseName.text.isEmpty) {
                    return showSnackbar(
                      context: context,
                      message: "Type Horse Name",
                    );
                  } else if (_age.text.isEmpty) {
                    return showSnackbar(
                      context: context,
                      message: "Type Age",
                    );
                  } else if (_selectedItem == null) {
                    return showSnackbar(
                      context: context,
                      message: "Select Team Type",
                    );
                  }
                  await FirebaseFirestore.instance
                      .collection(
                          'participant/${widget.eventID}/teams/$docId/teamMembers')
                      .doc()
                      .set({
                    'riderName': _riderName.text,
                    'horseName': _horseName.text,
                    'age': _age.text,
                    'riderType': _selectedItem,

                    // 'organizer': _eventorganizer.text,
                    // 'bankDetails': _bankDetails.text,
                    // 'accountNumber': _accountNo.text,
                    // 'createdAt': DateTime.now(),
                    // 'createdBy': provider.user.email,
                    // 'createdByName': provider.user.name,
                    // 'rejected': false,
                    // 'approved': false,
                  }).then((a) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Team Member Added Successfully'),
                        duration: Duration(seconds: 2),
                      ),
                    );
                    _riderName.clear();
                    _horseName.clear();
                    _age.clear();
                  });
                  setState(() {
                    addedTeam = true;
                  });
                },
                child: Container(
                  decoration: BoxDecoration(
                      color: Colors.blue,
                      borderRadius: BorderRadius.circular(20)),
                  height: 50,
                  width: 200,
                  child: const Center(child: Text('Add Team Member')),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(12.0),
              child: InkWell(
                onTap: () async {
                  if (addedTeam) {
                    print(docId);
                    await FirebaseFirestore.instance
                        .collection('participant/${widget.eventID}/teams')
                        .doc(docId)
                        .set({
                      'teamName': widget.teamName,
                      'captainName': widget.captain,
                      'totalMembers': widget.members,
                      'fullAddress': widget.address,

                      // 'organizer': _eventorganizer.text,
                      // 'bankDetails': _bankDetails.text,
                      // 'accountNumber': _accountNo.text,
                      // 'createdAt': DateTime.now(),
                      // 'createdBy': provider.user.email,
                      // 'createdByName': provider.user.name,
                      // 'rejected': false,
                      // 'approved': false,
                    }).then((a) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('Your Team Registered Successfully '),
                          duration: Duration(seconds: 2),
                        ),
                      );
                      Navigator.pushAndRemoveUntil<void>(
                        context,
                        CupertinoPageRoute(builder: (_) => const HomeScreen()),
                        (_) => false,
                      );
                    });
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Add atleast one Team Member'),
                        duration: Duration(seconds: 2),
                      ),
                    );
                  }
                },
                child: Container(
                  decoration: BoxDecoration(
                      color: addedTeam ? Colors.blue : Colors.blue,
                      borderRadius: BorderRadius.circular(20)),
                  height: 50,
                  width: 200,
                  child: const Center(child: Text('Complete')),
                ),
              ),
            ),
            const Text('Team Members'),
            StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection(
                      'participant/${widget.eventID}/teams/$docId/teamMembers')
                  .snapshots(),
              builder: (context, snapshot) {
                var data = snapshot.data;

                if (!snapshot.hasData) {
                  return const Center(
                    child: CircularProgressIndicator(color: Colors.black),
                  );
                }
                if (snapshot.data!.docs.isEmpty) {
                  return const Center(
                    child: Text('No Team Member added yet'),
                  );
                }

                return ListView.builder(
                  physics: const NeverScrollableScrollPhysics(),
                  shrinkWrap: true,
                  scrollDirection: Axis.vertical,
                  itemCount: data?.docs.length,
                  itemBuilder: (_, int i) {
                    // Timestamp date = data!.docs[i]['date'];
                    return Card(
                      child: ListTile(
                        title: Text(
                          data!.docs[i]['riderName'] ?? '',
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                        subtitle: Text(data.docs[i]['horseName'] ?? ''),
                      ),
                    );
                  },
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

class FormTextField extends StatelessWidget {
  final String hint;
  final bool isReadOnly;
  final VoidCallback? onTap;
  final TextEditingController controller;
  const FormTextField({
    Key? key,
    required this.hint,
    this.isReadOnly = false,
    this.onTap,
    required this.controller,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return TextField(
      onTap: onTap,
      readOnly: isReadOnly,
      controller: controller,
      keyboardType: TextInputType.text,
      decoration: InputDecoration(
        filled: true,
        hintText: hint,
        hoverColor: Colors.blue,
        fillColor: Colors.white,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }
}

class EventTypeWidget extends StatelessWidget {
  final KeyEventType type;
  final String selectedEventType;
  final void Function(String) onSelected;
  const EventTypeWidget({
    Key? key,
    required this.type,
    required this.selectedEventType,
    required this.onSelected,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: RadioListTile(
        value: true,
        groupValue: type.name == selectedEventType,
        onChanged: (value) {
          onSelected(type.name);
          return Navigator.of(context).pop();
        },
        title: Text(type.name),
      ),
    );
  }
}
