enum LoginResponse {
  success("Sign-in Successful"),
  error("Something went wrong! try again."),
  incorrectPassword("Password incorrect"),
  doesnotExists(
    "User is not registered with this email",
  );

  final String name;
  const LoginResponse(this.name);
}
