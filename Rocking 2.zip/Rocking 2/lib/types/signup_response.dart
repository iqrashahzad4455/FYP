enum SignupResponse {
  success("Account successfully created"),
  error("Something went wrong! try again."),
  alreadyExists(
    "User already have an account registered with this email address",
  );

  final String name;
  const SignupResponse(this.name);
}
