enum UserTypes {
  rider("Rider"),
  club("Club"),
  doctor("Doctor"),
  none("none"),
  productSeller("Product Seller");

  final String name;
  const UserTypes(this.name);
}

enum EventType {
  tentpeggiing("Tent Pegging"),
  horsebackarchery("Horse Back Archery"),
  showjumping("Show jumping"),
  horseracing("Horse Racing"),
  polo("Polo");

  final String event;
  const EventType(this.event);
}
