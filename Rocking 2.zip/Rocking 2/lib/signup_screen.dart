import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:rockingequestrian/functions/models/user_model.dart';
import 'package:rockingequestrian/functions/user_server/user_server.dart';
import 'package:rockingequestrian/meta/theme_meta.dart';
import 'package:rockingequestrian/types/user_Type.dart';
import 'package:rockingequestrian/utils/snackbar_utils.dart';

class SignUpScreen extends StatefulWidget {
  const SignUpScreen({super.key});

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  final TextEditingController name = TextEditingController();
  final TextEditingController email = TextEditingController();
  final TextEditingController dOB = TextEditingController();
  final TextEditingController type = TextEditingController();
  final TextEditingController password = TextEditingController();

  @override
  void dispose() {
    name.dispose();
    email.dispose();
    dOB.dispose();
    type.dispose();
    password.dispose();
    super.dispose();
  }

  /// signup user
  void signup() async {
    if (name.text.isEmpty) {
      return showSnackbar(context: context, message: "Enter your name");
    } else if (email.text.isEmpty) {
      return showSnackbar(context: context, message: "Enter your email");
    } else if (dOB.text.isEmpty) {
      return showSnackbar(
        context: context,
        message: "Select your date of birth",
      );
    } else if (type.text.isEmpty) {
      return showSnackbar(
        context: context,
        message: "Select account type",
      );
    } else if (password.text.isEmpty) {
      return showSnackbar(context: context, message: "Enter your Password");
    }
    // signup user details
    return await UserServer()
        .signupUser(
            user: UserModel(
                name: name.text,
                email: email.text,
                dOB: dOB.text,
                type: type.text,
                password: password.text))
        .then((res) {
      return showSnackbar(context: context, message: res.name);
    });
  }

  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.of(context).size;
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: AppTheme.brownBG,
      child: Scaffold(
        backgroundColor: Colors.blue,
        body: SafeArea(
          child: SizedBox(
            width: size.width,
            height: size.height,
            child: SingleChildScrollView(
              clipBehavior: Clip.antiAliasWithSaveLayer,
              physics: const AlwaysScrollableScrollPhysics(),
              padding: EdgeInsets.symmetric(horizontal: size.width * 0.06),
              child: Column(
                children: [
                  SizedBox(height: size.height * 0.08),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(90),
                    child: Image.asset(
                      "images/logo.png",
                      height: size.height * 0.2,
                      width: size.height * 0.2,
                      fit: BoxFit.cover,
                    ),
                  ),
                  SizedBox(height: size.height * 0.05),
                  TextField(
                    controller: name,
                    decoration: InputDecoration(
                      hoverColor: Colors.teal,
                      fillColor: Colors.white,
                      filled: true,
                      hintText: "Name",
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  ),
                  SizedBox(height: size.height * 0.01),
                  TextField(
                    controller: email,
                    decoration: InputDecoration(
                      hoverColor: Colors.blue,
                      fillColor: Colors.white,
                      filled: true,
                      hintText: "Email",
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  ),
                  SizedBox(height: size.height * 0.01),
                  TextFormField(
                    readOnly: true,
                    controller: dOB,
                    autofocus: false,
                    onTap: () async {
                      final DateTime? date = await showDatePicker(
                        context: context,
                        firstDate: DateTime(1947),
                        lastDate: DateTime(2023),
                        initialDate: DateTime.now(),
                      );
                      // Check if User has picked a date or not
                      if (date != null) {
                        dOB.text = "${date.month}/${date.day}/${date.year}";
                      }
                    },
                    decoration: InputDecoration(
                      hoverColor: Colors.pink,
                      fillColor: Colors.white,
                      filled: true,
                      hintText: "MM/DD/YY",
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  ),
                  SizedBox(height: size.height * 0.01),
                  TextField(
                    readOnly: true,
                    autofocus: false,
                    controller: type,
                    onTap: () async {
                      showCupertinoDialog(
                        context: context,
                        builder: (context) {
                          return CupertinoAlertDialog(
                            title: const Text("Pick User Type"),
                            actions: [
                              MaterialButton(
                                child: const Text("Cancel"),
                                onPressed: () => Navigator.pop(context),
                              ),
                            ],
                            content: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                UserTypeWidget(
                                  onSelected: (String userType) {
                                    type.text = userType;
                                    return;
                                  },
                                  selectedUserType: type.text,
                                  type: UserTypes.club,
                                ),
                                UserTypeWidget(
                                  onSelected: (String userType) {
                                    type.text = userType;
                                    return;
                                  },
                                  selectedUserType: type.text,
                                  type: UserTypes.doctor,
                                ),
                                UserTypeWidget(
                                  onSelected: (String userType) {
                                    type.text = userType;
                                    return;
                                  },
                                  selectedUserType: type.text,
                                  type: UserTypes.productSeller,
                                ),
                                UserTypeWidget(
                                  onSelected: (String userType) {
                                    type.text = userType;
                                    return;
                                  },
                                  selectedUserType: type.text,
                                  type: UserTypes.rider,
                                ),
                              ],
                            ),
                          );
                        },
                      );
                    },
                    decoration: InputDecoration(
                      hoverColor: const Color.fromARGB(255, 241, 81, 70),
                      fillColor: Colors.white,
                      filled: true,
                      hintText: "Account Type",
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  ),
                  SizedBox(height: size.height * 0.01),
                  TextField(
                    controller: password,
                    decoration: InputDecoration(
                      hoverColor: const Color.fromARGB(255, 91, 177, 94),
                      fillColor: Colors.white,
                      filled: true,
                      hintText: "Password",
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  ),
                  SizedBox(height: size.height * 0.03),
                  MaterialButton(
                    height: 52,
                    color: Colors.white,
                    minWidth: MediaQuery.of(context).size.width,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    child: const Text(
                      "Sign Up",
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    onPressed: () => signup(),
                  ),
                  SizedBox(height: size.height * 0.02),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class UserTypeWidget extends StatelessWidget {
  final UserTypes type;
  final String selectedUserType;
  final void Function(String) onSelected;
  const UserTypeWidget({
    Key? key,
    required this.type,
    required this.onSelected,
    required this.selectedUserType,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: RadioListTile(
        value: true,
        groupValue: type.name == selectedUserType,
        onChanged: (value) {
          onSelected(type.name);
          return Navigator.of(context).pop();
        },
        title: Text(type.name),
      ),
    );
  }
}
