import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:rockingequestrian/chatsampel.dart';
import 'package:rockingequestrian/database/user_database.dart';
import 'package:rockingequestrian/functions/chat_server/chat_server.dart';
import 'package:rockingequestrian/functions/models/chat_model.dart';
import 'package:rockingequestrian/functions/models/user_model.dart';
import 'package:rockingequestrian/provider/user_provider.dart';
import 'package:rockingequestrian/user-profile.dart';
import 'package:rockingequestrian/utils/snackbar_utils.dart';
import 'package:rockingequestrian/widgets/guest_mode_listenable/guest_mode_listenable_widget.dart';

class ChatPage extends StatefulWidget {
  final UserModel user;
  const ChatPage({super.key, required this.user});

  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final ChatServer _chatServer = ChatServer(
    userDatabase: UserDatabase.instance,
    firestore: FirebaseFirestore.instance,
  );

  final UserDatabase _userDB = UserDatabase.instance;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.withOpacity(0.3),
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(65),
        child: AppBar(
          backgroundColor: Colors.blue,
          elevation: 0,
          actions: [
            PopupMenuButton(
              itemBuilder: (context) => [
                PopupMenuItem(
                  value: 1,
                  onTap: () {
                    _chatServer.deleteUserChat(userId1: widget.user.email);
                  },
                  child: const Text(
                    "Delete",
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
                const PopupMenuItem(
                  value: 2,
                  child: Text(
                    "Block",
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ],
            ),
          ],
          leading: Padding(
            padding: const EdgeInsets.only(
              top: 10,
              left: 6,
            ),
            child: IconButton(
              onPressed: () {
                Navigator.pop(context);
              },
              icon: const Icon(
                Icons.arrow_back,
                size: 24,
              ),
            ),
          ),
          leadingWidth: 40,
          title: Padding(
            padding: const EdgeInsets.only(top: 5.5),
            child: GestureDetector(
              onTap: () {
                Navigator.push<void>(
                  context,
                  CupertinoPageRoute(
                    builder: (_) => UserProfileView(user: widget.user),
                  ),
                );
              },
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(30),
                    child: Image.asset(
                      "images/logo3.jpg",
                      height: 45,
                      width: 45,
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          widget.user.name,
                          style: const TextStyle(fontSize: 19),
                        ),
                        const SizedBox(height: 5),
                        const Text(
                          " ",
                          style: TextStyle(fontSize: 15, color: Colors.white54),
                        ),
                      ],
                    ),
                  )
                ],
              ),
            ),
          ),
        ),
      ),
      body: SizedBox(
        width: double.infinity,
        height: double.infinity,
        child: GuestModeListenable(
          listenable: context.read<UserProvider>().userDB.listenable,
          guest: (_) => const Center(
            child: Text(
              "Please login to chat with users",
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.normal,
              ),
            ),
          ),
          child: (_) => Column(
            children: [
              Expanded(
                child: StreamBuilder<List<ChatModel>>(
                  initialData: const <ChatModel>[],
                  stream:
                      _chatServer.getMessagesStream(userId1: widget.user.email),
                  builder: (_, AsyncSnapshot<List<ChatModel>> snapshot) {
                    if (snapshot.connectionState == ConnectionState.active) {
                      if (snapshot.hasData && snapshot.data != null) {
                        if (snapshot.data?.isNotEmpty ?? false) {
                          return ListView.builder(
                            reverse: true,
                            itemCount: snapshot.data?.length ?? 0,
                            clipBehavior: Clip.antiAliasWithSaveLayer,
                            physics: const AlwaysScrollableScrollPhysics(),
                            padding: const EdgeInsets.symmetric(
                              vertical: 5,
                              horizontal: 15,
                            ),
                            itemBuilder: (_, int index) {
                              final ChatModel chat =
                                  snapshot.data?[index] ?? const ChatModel();
                              if (chat.senderID == _userDB.getUID) {
                                return SentMessage(
                                  chat: chat,
                                  server: _chatServer,
                                );
                              } else {
                                return ReceivedMessage(
                                  chat: chat,
                                  server: _chatServer,
                                );
                              }
                            },
                          );
                        } else {
                          return const Center(child: Text("No Messages Found"));
                        }
                      } else {
                        return const Center(child: Text("No Messages Found"));
                      }
                    }
                    return const Center(child: CircularProgressIndicator());
                  },
                ),
              ),
              ChatBottomTextField(user: widget.user),
            ],
          ),
        ),
      ),
    );
  }
}

class ChatBottomTextField extends StatefulWidget {
  final UserModel user;
  const ChatBottomTextField({super.key, required this.user});

  @override
  State<ChatBottomTextField> createState() => _ChatBottomTextFieldState();
}

class _ChatBottomTextFieldState extends State<ChatBottomTextField> {
  final TextEditingController controller = TextEditingController();
  final ChatServer _chatServer = ChatServer(
    userDatabase: UserDatabase.instance,
    firestore: FirebaseFirestore.instance,
  );

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.transparent,
      width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height * 0.085,
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      child: Row(
        children: [
          Expanded(
            child: TextFormField(
              controller: controller,
              decoration: InputDecoration(
                filled: true,
                fillColor: Colors.white,
                hintText: "Type your Message",
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(25),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(25),
                ),
              ),
            ),
          ),
          const SizedBox(width: 10),
          GestureDetector(
            onTap: () {
              if (controller.text.isNotEmpty) {
                _chatServer
                    .sendMessage(
                        message: controller.text, receiverID: widget.user.email)
                    .then((_) {
                  return controller.clear();
                });
              } else {
                return showSnackbar(
                  message: "Message Can't be Empty",
                  context: context,
                );
              }
            },
            child: CircleAvatar(
              radius: 24,
              backgroundColor: Colors.blue.shade400,
              child: const Icon(
                size: 20,
                Icons.send_outlined,
                color: Colors.white,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
