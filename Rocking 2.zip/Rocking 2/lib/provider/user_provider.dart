import 'dart:async';
import 'dart:developer';
import 'package:flutter/foundation.dart';
import 'package:rockingequestrian/database/user_database.dart';
import 'package:rockingequestrian/functions/models/user_model.dart';
import 'package:rockingequestrian/functions/post_server/post_server.dart';
import 'package:rockingequestrian/functions/uploader_storage/uploader_storage.dart';
import 'package:rockingequestrian/functions/user_server/user_server.dart';

class UserProvider extends ChangeNotifier {
  /// Create an Instance `UserDatabase`
  final UserDatabase userDB = UserDatabase.instance;

  /// Create an Instance `UserServer`
  UserServer get userServer => _userServer;
  final UserServer _userServer = UserServer();

  /// Create an Instance `UploaderStorage`
  UploaderStorage get uploaderStorage => _uploaderStorage;
  final UploaderStorage _uploaderStorage = UploaderStorage();

  /// Create an Instance `PostServer`
  PostServer get postServer => _postServer;
  final PostServer _postServer = PostServer();

  /// Hold User Account Information
  UserModel get user {
    _user ??= UserModel(
      email: userDB.getUID ?? "",
      password: userDB.getPWD ?? "",
      name: userDB.getName ?? "",
    );
    return _user!;
  }

  UserModel? _user;

  void initialize() {
    _streamSubscription?.cancel();
    _streamSubscription = null;
    // Check if user details are not null then listen to it
    if (userDB.getUID != null && userDB.getUID!.isNotEmpty) {
      // lISTEN TO DTabase changes
      _userDatabaseListener();
    }
    // Listen to Database Changes
    userDB.listen(_userDatabaseListener);
  }

  /// Create an Instance of `StreamSubscription<UserModel> `
  StreamSubscription<UserModel>? _streamSubscription;

  /// Listen to `UserDatabase` Changes
  void _userDatabaseListener() {
    // Check if Database is Empty or not
    if (userDB.getUID?.isNotEmpty ?? false) {
      _streamSubscription =
          _userServer.getUserById(userDB.getUID!).listen((UserModel u) {
        // check if event details contain user email then assign it
        if (u.email.isNotEmpty) {
          /// Print User Details
          if (kDebugMode) {
            log("User Email: ${u.email}");
          }
          // Assign User details
          _user = u;
          notifyListeners();
        }
      });
    }
  }

  @override
  void dispose() {
    _streamSubscription?.cancel();
    super.dispose();
  }
}
