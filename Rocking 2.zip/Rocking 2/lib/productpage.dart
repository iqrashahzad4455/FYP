import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:rockingequestrian/functions/uploader_storage/uploader_storage.dart';
import 'package:rockingequestrian/provider/user_provider.dart';
import 'package:rockingequestrian/types/user_type.dart';
import 'package:rockingequestrian/utils/image_picker_utils.dart';
import 'package:rockingequestrian/utils/snackbar_utils.dart';
import 'package:rockingequestrian/widgets/avatar/user_avatar_widget.dart';

class Product extends StatefulWidget {
  const Product({super.key});

  @override
  State<Product> createState() => _ProductState();
}

class _ProductState extends State<Product> {
  late final UserProvider provider;

  @override
  void initState() {
    provider = context.read<UserProvider>();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.blue,
        title: const Text("Products"),
        actions: [
          if (provider.user.type == UserTypes.productSeller.name)
            ElevatedButton.icon(
              onPressed: () {
                Navigator.of(context).push(
                  CupertinoPageRoute(builder: (_) => const AddProductPage()),
                );
                return;
              },
              label: const Text("Add Product"),
              icon: const Icon(CupertinoIcons.add),
            ),
          SizedBox(width: size.width * 0.02),
        ],
      ),
      body: SafeArea(
        child: SizedBox(
          width: size.width,
          height: size.height,
          child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
            stream:
                FirebaseFirestore.instance.collection("products").snapshots(),
            builder: (_, AsyncSnapshot<QuerySnapshot<Map<String, dynamic>>> s) {
              if (s.connectionState == ConnectionState.active) {
                if (s.hasData && s.data != null && s.data!.docs.isNotEmpty) {
                  return ListView.builder(
                    itemCount: s.data?.docs.length ?? 0,
                    clipBehavior: Clip.antiAliasWithSaveLayer,
                    padding: EdgeInsets.symmetric(
                      horizontal: size.width * 0.035,
                    ),
                    itemBuilder: (_, int i) {
                      final String title = s.data!.docs[i].data()['title'];
                      final String content = s.data!.docs[i].data()['content'];
                      final String price = s.data!.docs[i].data()['price'];
                      final String thumbnail =
                          s.data!.docs[i].data()['thumbnail'];
                      final String sellerName =
                          s.data!.docs[i].data()['seller_name'];
                      final String sellerEmail =
                          s.data!.docs[i].data()['seller_email'];
                      final String sellerProfile =
                          s.data!.docs[i].data()['seller_profile'];
                      return Card(
                        color: Colors.white,
                        surfaceTintColor: Colors.white,
                        clipBehavior: Clip.antiAliasWithSaveLayer,
                        shape: RoundedRectangleBorder(
                          borderRadius:
                              BorderRadius.circular(size.height * 0.02),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            CachedNetworkImage(
                              fit: BoxFit.cover,
                              width: size.width,
                              imageUrl: thumbnail,
                              height: size.height * 0.25,
                            ),
                            SizedBox(height: size.height * 0.015),
                            Padding(
                              padding: EdgeInsets.symmetric(
                                horizontal: size.width * 0.02,
                              ),
                              child: Row(
                                children: [
                                  Expanded(
                                    child: Text(
                                      title,
                                      textAlign: TextAlign.start,
                                      style: const TextStyle(
                                        fontSize: 19,
                                        color: Colors.black,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                  ),
                                  SizedBox(width: size.width * 0.015),
                                  Text(
                                    "Price: $price",
                                    textAlign: TextAlign.start,
                                    style: TextStyle(
                                      fontSize: 12,
                                      color: Colors.black.withOpacity(0.7),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.symmetric(
                                horizontal: size.width * 0.02,
                                vertical: size.height * 0.007,
                              ),
                              child: Text(
                                content,
                                textAlign: TextAlign.start,
                                style: TextStyle(
                                  color: Colors.black.withOpacity(0.75),
                                ),
                              ),
                            ),
                            SizedBox(height: size.height * 0.015),
                            Padding(
                              padding: EdgeInsets.symmetric(
                                horizontal: size.width * 0.02,
                              ),
                              child: Row(
                                children: [
                                  UserAvatar(
                                    url: sellerProfile,
                                    width: size.height * 0.05,
                                    height: size.height * 0.05,
                                  ),
                                  SizedBox(width: size.width * 0.02),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          sellerName,
                                          textAlign: TextAlign.start,
                                          style: TextStyle(
                                            fontSize: 15,
                                            fontWeight: FontWeight.w600,
                                            color:
                                                Colors.black.withOpacity(0.85),
                                          ),
                                        ),
                                        Text(
                                          sellerEmail,
                                          textAlign: TextAlign.start,
                                          style: TextStyle(
                                            fontSize: 11,
                                            color:
                                                Colors.black.withOpacity(0.75),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  SizedBox(width: size.width * 0.015),
                                  ElevatedButton.icon(
                                    onPressed: () {},
                                    label: const Text(
                                      "Contact",
                                      style: TextStyle(color: Colors.white),
                                    ),
                                    icon:
                                        const Icon(CupertinoIcons.chat_bubble),
                                    style: ButtonStyle(
                                      backgroundColor:
                                          MaterialStateProperty.all(
                                        Colors.blue,
                                      ),
                                      iconColor: MaterialStateProperty.all(
                                        Colors.white,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(height: size.height * 0.02),
                          ],
                        ),
                      );
                    },
                  );
                }
                return const Center(
                  child: Text(
                    "No Product Found",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 17,
                      color: Colors.black,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                );
              }
              return const Center(child: CircularProgressIndicator.adaptive());
            },
          ),
        ),
      ),
    );
  }
}

class AddProductPage extends StatefulWidget {
  const AddProductPage({super.key});

  @override
  State<AddProductPage> createState() => _AddProductPageState();
}

class _AddProductPageState extends State<AddProductPage> {
  late final UserProvider provider;

  @override
  void initState() {
    provider = context.read<UserProvider>();
    super.initState();
  }

  final TextEditingController _title = TextEditingController();
  final TextEditingController _body = TextEditingController();
  final TextEditingController _price = TextEditingController();

  /// Hold Image File
  File? _productThumbnail;

  @override
  void dispose() {
    _title.dispose();
    _body.dispose();
    _price.dispose();
    super.dispose();
  }

  /// Hold IsEnabled for product to add
  bool isEnabled = true;

  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colors.blue,
      appBar: AppBar(
        backgroundColor: Colors.blue,
        title: const Text("Add Product"),
      ),
      body: SafeArea(
        child: SizedBox(
          width: size.width,
          height: size.height,
          child: SingleChildScrollView(
            clipBehavior: Clip.antiAliasWithSaveLayer,
            physics: const AlwaysScrollableScrollPhysics(),
            padding: EdgeInsets.symmetric(horizontal: size.width * 0.04),
            child: Column(
              children: [
                SizedBox(height: size.height * 0.04),
                GestureDetector(
                  onTap: () async {
                    if (!isEnabled) {
                      return;
                    }
                    return ImagePickerUtils.instance
                        .pickCamera()
                        .then<void>((File? value) {
                      return setState(() {
                        _productThumbnail = value;
                      });
                    });
                  },
                  child: Column(
                    children: [
                      if (_productThumbnail != null)
                        ClipRRect(
                          clipBehavior: Clip.antiAliasWithSaveLayer,
                          borderRadius:
                              BorderRadius.circular(size.height * 0.02),
                          child: Image.file(
                            _productThumbnail!,
                            fit: BoxFit.fill,
                            width: size.width,
                            height: size.height * 0.25,
                          ),
                        )
                      else
                        Icon(CupertinoIcons.photo, size: size.height * 0.25),
                    ],
                  ),
                ),
                SizedBox(height: size.height * 0.025),
                TextField(
                  enabled: isEnabled,
                  controller: _title,
                  textAlign: TextAlign.start,
                  keyboardType: TextInputType.text,
                  textInputAction: TextInputAction.next,
                  decoration: InputDecoration(
                    filled: true,
                    border: border,
                    errorBorder: border,
                    enabledBorder: border,
                    focusedBorder: border,
                    hintText: "Add Product Title",
                    disabledBorder: border,
                    hoverColor: Colors.blue,
                    fillColor: Colors.white,
                    focusedErrorBorder: border,
                    prefixIcon: const Icon(Icons.production_quantity_limits),
                  ),
                ),
                SizedBox(height: size.height * 0.02),
                TextField(
                  controller: _body,
                  enabled: isEnabled,
                  textAlign: TextAlign.start,
                  keyboardType: TextInputType.text,
                  textInputAction: TextInputAction.next,
                  decoration: InputDecoration(
                    filled: true,
                    border: border,
                    errorBorder: border,
                    enabledBorder: border,
                    focusedBorder: border,
                    hintText: "Type Product Description",
                    disabledBorder: border,
                    hoverColor: Colors.blue,
                    fillColor: Colors.white,
                    focusedErrorBorder: border,
                    prefixIcon: const Icon(Icons.production_quantity_limits),
                  ),
                ),
                SizedBox(height: size.height * 0.02),
                TextField(
                  controller: _price,
                  enabled: isEnabled,
                  textAlign: TextAlign.start,
                  keyboardType: TextInputType.number,
                  textInputAction: TextInputAction.done,
                  decoration: InputDecoration(
                    filled: true,
                    border: border,
                    errorBorder: border,
                    enabledBorder: border,
                    focusedBorder: border,
                    hintText: "Type Product Price",
                    disabledBorder: border,
                    hoverColor: Colors.blue,
                    fillColor: Colors.white,
                    focusedErrorBorder: border,
                    prefixIcon: const Icon(Icons.production_quantity_limits),
                  ),
                ),
                SizedBox(height: size.height * 0.02),
                MaterialButton(
                  height: 60,
                  elevation: 1.0,
                  color: Colors.white,
                  minWidth: MediaQuery.of(context).size.width,
                  clipBehavior: Clip.antiAliasWithSaveLayer,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  onPressed: () async {
                    if (!isEnabled) {
                      return;
                    }
                    // Validate add product details
                    if (_productThumbnail == null) {
                      return showSnackbar(
                        context: context,
                        message: "Add Product Thumbnail",
                      );
                    } else if (_title.text.isEmpty) {
                      return showSnackbar(
                        context: context,
                        message: "Add Product Title",
                      );
                    } else if (_body.text.isEmpty) {
                      return showSnackbar(
                        context: context,
                        message: "Add Product Descritpion",
                      );
                    } else if (_price.text.isEmpty) {
                      return showSnackbar(
                        context: context,
                        message: "Add Product Price",
                      );
                    }
                    // Mark is enabled to false
                    setState(() {
                      isEnabled = false;
                    });
                    // Start Upload product in firebase firestore
                    final String? productUrl = await UploaderStorage()
                        .uploadProduct(_productThumbnail!);
                    // Now add product in database
                    await FirebaseFirestore.instance
                        .collection("products")
                        .add({
                      "title": _title.text,
                      "content": _body.text,
                      "price": _price.text,
                      "thumbnail": productUrl,
                      "seller_name": provider.user.name,
                      "seller_email": provider.user.email,
                      "seller_profile": provider.user.profileUrl,
                    });
                    // Now clear the fields
                    _title.clear();
                    _body.clear();
                    _price.clear();
                    setState(() {
                      // Mark is enabled to true
                      isEnabled = true;
                      _productThumbnail = null;
                    });
                    // Show snackbar
                    return showSnackbar(
                      context: context,
                      message: "Product successfully.",
                    );
                  },
                  child: const Text("Add Product"),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  OutlineInputBorder get border {
    return OutlineInputBorder(borderRadius: BorderRadius.circular(15));
  }
}
