import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:rockingequestrian/functions/extensions/string/string.extensions.fucntions.dart';
import 'package:rockingequestrian/functions/models/notification_model.dart';
import 'package:rockingequestrian/functions/models/post_model.dart';
import 'package:rockingequestrian/provider/user_provider.dart';
import 'package:rockingequestrian/types/user_type.dart';
import 'package:rockingequestrian/widgets/avatar/user_avatar_widget.dart';
import 'package:rockingequestrian/widgets/guest_mode_listenable/guest_mode_listenable_widget.dart';

class AddNewPost extends StatefulWidget {
  const AddNewPost({super.key});

  @override
  State<AddNewPost> createState() => _AddNewPostState();
}

class _AddNewPostState extends State<AddNewPost>
    with AutomaticKeepAliveClientMixin {
  /// Select Media Files and Hold here
  final List<XFile> _files = <XFile>[];

  /// Create an Instance of `ImagePicker`
  final ImagePicker _picker = ImagePicker();

  Future getImage(bool iscamera) async {
    // Hold selected file
    XFile? file;
    // Select File from Gallery or Camera
    if (iscamera) {
      file = await _picker.pickImage(source: ImageSource.camera);
    } else {
      file = await _picker.pickImage(source: ImageSource.gallery);
    }
    // Check if File not null and path is not empty then add it to list
    if (file != null && file.path.isNotEmpty) {
      _files.add(file);
      return setState(() {});
    }
    return;
  }

  /// Delete Selected Image from List
  void _deleteFile(XFile file) {
    // Check if list is empty
    if (_files.isNotEmpty) {
      _files.removeWhere((XFile i) => i.path.isSame(file.path));
    }
    return setState(() {});
  }

  /// Create an instance of `TextEditingController`
  final TextEditingController _postText = TextEditingController();

  /// Add Post Into Database
  void _addPost() async {
    /// Hold Temprary Url or media files
    final List<String> mediaFilesUrl = <String>[];
    // Check if user has enetered Something
    if (_postText.text.isEmpty) {
      return "Write Something to Post".snackbar(context);
    }
    // Check if MediaFiles are not empty
    if (_files.isNotEmpty) {
      for (XFile i in _files) {
        final String? path =
            await provider.uploaderStorage.uploadMedia(File(i.path));
        // Check if Path is not empty then add it to _mediaFiles list
        if (path != null && path.isNotEmpty) {
          mediaFilesUrl.add(path);
        }
      }
    }
    // Add Post into Database
    final PostModel model = PostModel(
      media: mediaFilesUrl,
      content: _postText.text,
      userID: provider.user.email,
      postBy: provider.user.name,
      userType: UserTypes.values.toList().firstWhere(
            orElse: () => UserTypes.none,
            (UserTypes e) => e.name.isSame(provider.user.type),
          ),
    );
    // Add New Post Into Database
    provider.postServer.addPost(model).then<void>((bool result) {
      // Clear Media
      clear();
      // Post Added Successfully check if result is true
      if (result) {
        return "Post Added Successfully".snackbar(context);
      } else {
        return "Failed to Add Post".snackbar(context);
      }
    });
    // Send notifications to all my followers
    for (String e in provider.user.followersList) {
      provider.userServer.storeNotification(
        userId: e,
        notification: NotificationModel(
          name: provider.user.name,
          title: "Add new post",
          userProfileUrl: provider.user.profileUrl,
        ),
      );
    }
    return;
  }

  /// Clear Everything
  void clear() {
    _files.clear();
    _postText.clear();
    return setState(() {});
  }

  /// Create an Instance of  `UserProvider`
  late final UserProvider provider;

  @override
  void initState() {
    provider = context.read<UserProvider>();
    super.initState();
  }

  @override
  void dispose() {
    _postText.dispose();
    backgroundColor.close();
    super.dispose();
  }

  // Hold Background COlor
  final StreamController<Color> backgroundColor =
      StreamController<Color>.broadcast();

  // Update BackgroundColor
  void updateBackgroundColor(Color c) {
    // Make sure stream is not closed;
    if (!backgroundColor.isClosed) {
      backgroundColor.sink.add(c);
    }
    return;
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final Size size = MediaQuery.of(context).size;
    return StreamBuilder<Color>(
      initialData: Colors.white,
      stream: backgroundColor.stream,
      builder: (_, AsyncSnapshot<Color> snap) {
        return Scaffold(
          backgroundColor: snap.data,
          body: SafeArea(
            child: Container(
              width: size.width,
              height: size.height,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: GuestModeListenable(
                listenable: provider.userDB.listenable,
                guest: (_) {
                  // Change Background Color to White
                  updateBackgroundColor(Colors.white);
                  return const Center(
                    child: Text(
                      "Please login to add new posts",
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 16),
                    ),
                  );
                },
                child: (_) {
                  // Change Background Color to Brown
                  updateBackgroundColor(Colors.white);
                  // return the widget
                  return SingleChildScrollView(
                    padding: EdgeInsets.zero,
                    clipBehavior: Clip.antiAliasWithSaveLayer,
                    physics: const AlwaysScrollableScrollPhysics(),
                    child: Column(
                      children: [
                        const SizedBox(height: 30),
                        SizedBox(
                          width: size.width,
                          child: Row(
                            children: [
                              Consumer<UserProvider>(
                                builder: (_, UserProvider pro, __) {
                                  return CircleAvatar(
                                    radius: 30,
                                    backgroundColor: Colors.white,
                                    child: UserAvatar(url: pro.user.profileUrl),
                                  );
                                },
                              ),
                              const SizedBox(width: 20),
                              Expanded(
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment:
                                      CrossAxisAlignment.stretch,
                                  children: [
                                    Text(
                                      provider.user.name,
                                      style: const TextStyle(
                                        fontSize: 19,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    const SizedBox(height: 4),
                                    Row(
                                      children: const [
                                        Icon(Icons.public_outlined),
                                        SizedBox(width: 10),
                                        Text("Public"),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 15),
                        TextField(
                          maxLines: 10,
                          controller: _postText,
                          keyboardType: TextInputType.multiline,
                          decoration: const InputDecoration(
                            hintText: "What do you want talk about",
                          ),
                        ),
                        const SizedBox(height: 20),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            GestureDetector(
                              onTap: () => getImage(true),
                              child: const CircleAvatar(
                                radius: 25,
                                backgroundColor: Colors.blue,
                                child: Icon(
                                  Icons.camera_alt_outlined,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                            const SizedBox(width: 15),
                            GestureDetector(
                              onTap: () => getImage(false),
                              child: const CircleAvatar(
                                radius: 25,
                                backgroundColor: Colors.blue,
                                child: Icon(
                                  Icons.photo_outlined,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                            const Spacer(),
                            MaterialButton(
                              height: 48,
                              minWidth: 150,
                              onPressed: _addPost,
                              color: Colors.blue,
                              clipBehavior: Clip.antiAliasWithSaveLayer,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: const Text(
                                "Publish",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontSize: 15,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 20),
                        SizedBox(
                          width: size.width,
                          child: Wrap(
                            spacing: 8.0,
                            runSpacing: 8.0,
                            alignment: WrapAlignment.start,
                            children: _files.map<Widget>((e) {
                              return AddPostImage(
                                file: e,
                                onDeleteTap: _deleteFile,
                              );
                            }).toList(),
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ),
        );
      },
    );
  }

  @override
  bool get wantKeepAlive => true;
}

class AddPostImage extends StatelessWidget {
  final XFile file;
  final void Function(XFile file) onDeleteTap;
  const AddPostImage({
    super.key,
    required this.file,
    required this.onDeleteTap,
  });

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(12),
      clipBehavior: Clip.antiAliasWithSaveLayer,
      child: GestureDetector(
        onLongPress: () => onDeleteTap(file),
        child: Image.file(
          width: 100,
          height: 100,
          File(file.path),
          fit: BoxFit.cover,
        ),
      ),
    );
  }
}
