// import 'package:admin_rocking_equestrian/widgets/adminWidgets.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:rockingequestrian/addParticipant.dart';
import 'package:rockingequestrian/eventWidget.dart';

class UpComminEvents extends StatefulWidget {
  const UpComminEvents({super.key});

  @override
  State<UpComminEvents> createState() => _UpComminEventsState();
}

class _UpComminEventsState extends State<UpComminEvents> {
  @override
  void initState() {
    fetchEvents();
    super.initState();
  }

  fetchEvents() async {
    print('object');
    await FirebaseFirestore.instance
        .collection('events')
        .orderBy('createdAt', descending: true)
        .get()
        .then((value) {
      print(value.docs.length);
      // events.addAll(value.docs);
      setState(() {
        events = value.docs;
      });
      print(events);
    }).whenComplete(() {
      loaded = true;
    });
  }

  bool loaded = false;
  List events = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.blue,
        title: const Text(
          'UpComming Events',
          style: TextStyle(color: Colors.black),
        ),
      ),
      body: loaded
          ? ListView.builder(
              scrollDirection: Axis.vertical,
              itemCount: events.length,
              shrinkWrap: true,
              itemBuilder: (_, index) {
                return events[index]['approved']
                    ? InkWell(
                        onTap: () {
                          final navigator = Navigator.of(context);
                          navigator.push(
                            CupertinoPageRoute(
                              builder: (_) =>
                                  AddParticipant(eventID: events[index].id),
                            ),
                          );
                        },
                        child: AccountManagementWidget(
                          eventID: events[index].id,
                          eventName: events[index]['name'],
                          eventType: events[index]['eventType'],
                          eventDate: events[index]['date'],
                          eventTime: events[index]['time'],
                          eventAddress: events[index]['address'],
                          eventOragnizer: events[index]['organizer'],
                          bankDetails: events[index]['bankDetails'],
                          accountNumber: events[index]['accountNumber'],
                          createdDate: events[index]['createdAt'],
                          createdBy: events[index]['createdBy'],
                          createdByName: events[index]['createdByName'],
                          approved: events[index]['approved'],
                        ),
                      )
                    : const SizedBox();
              },
            )
          : const Center(
              child: CircularProgressIndicator(color: Colors.white),
            ),
    );
  }
}
