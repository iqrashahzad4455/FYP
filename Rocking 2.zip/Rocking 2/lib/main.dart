import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:get_storage/get_storage.dart';
import 'package:provider/provider.dart';
import 'package:rockingequestrian/database/user_database.dart';
import 'package:rockingequestrian/firebase_options.dart';
import 'package:rockingequestrian/meta/settings_meta.dart';
import 'package:rockingequestrian/provider/user_provider.dart';
import 'package:rockingequestrian/screens/splash/splash_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await GetStorage.init(UserDatabase.container);
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(const InitialView());
}

class InitialView extends StatelessWidget {
  const InitialView({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider<UserProvider>(create: (_) => UserProvider()),
      ],
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () => FocusManager.instance.primaryFocus?.unfocus(),
        child: MaterialApp(
          themeMode: ThemeMode.light,
          home: const SplashScreen(),
          title: AppSettings.appName,
          debugShowCheckedModeBanner: false,
          theme: ThemeData.light(useMaterial3: true).copyWith(
            appBarTheme: AppBarTheme(
              iconTheme: IconThemeData(color: Colors.black.withOpacity(0.75)),
              actionsIconTheme: IconThemeData(
                color: Colors.black.withOpacity(0.75),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
