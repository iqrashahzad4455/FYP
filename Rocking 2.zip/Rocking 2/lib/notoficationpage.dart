import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:rockingequestrian/coustomfollownotification.dart';
import 'package:rockingequestrian/database/user_database.dart';
import 'package:rockingequestrian/functions/models/notification_model.dart';
import 'package:rockingequestrian/provider/user_provider.dart';
import 'package:rockingequestrian/widgets/guest_mode_listenable/guest_mode_listenable_widget.dart';

class NotificationPage extends StatefulWidget {
  const NotificationPage({super.key});

  @override
  State<NotificationPage> createState() => _NotificationPageState();
}

class _NotificationPageState extends State<NotificationPage>
    with AutomaticKeepAliveClientMixin {
  late final UserProvider provider;

  @override
  void initState() {
    provider = context.read<UserProvider>();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colors.white,
      body: SizedBox(
        width: size.width,
        height: size.height,
        child: GuestModeListenable(
          listenable: provider.userDB.listenable,
          guest: (_) => const Center(
            child: Text(
              "Please login see notifications",
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.normal,
              ),
            ),
          ),
          child: (_) => StreamBuilder<List<NotificationModel>>(
            stream: provider.userServer
                .getNotificationsById(UserDatabase.instance.getUID ?? ""),
            builder: (_, AsyncSnapshot<List<NotificationModel>> s) {
              if (s.hasData && s.data != null && s.data!.isNotEmpty) {
                return ListView.builder(
                  itemCount: s.data?.length ?? 0,
                  clipBehavior: Clip.antiAliasWithSaveLayer,
                  physics: const AlwaysScrollableScrollPhysics(),
                  padding: EdgeInsets.symmetric(horizontal: size.width * 0.03),
                  itemBuilder: (_, int i) {
                    return Padding(
                      padding: EdgeInsets.only(
                        bottom: size.height * 0.02,
                        top: i == 0 ? size.height * 0.025 : 0.0,
                      ),
                      child: NotificationCard(notification: s.data![i]),
                    );
                  },
                );
              } else if (s.connectionState != ConnectionState.active) {
                return const Center(child: CircularProgressIndicator());
              } else {
                return const Center(child: Text("No Notification Found"));
              }
            },
          ),
        ),
      ),
    );
  }

  @override
  bool get wantKeepAlive => true;
}
