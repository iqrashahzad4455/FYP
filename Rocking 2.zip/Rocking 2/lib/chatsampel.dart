import 'package:custom_clippers/custom_clippers.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:rockingequestrian/functions/chat_server/chat_server.dart';
import 'package:rockingequestrian/functions/models/chat_model.dart';

class SentMessage extends StatelessWidget {
  final ChatModel chat;
  final ChatServer server;
  const SentMessage({super.key, required this.chat, required this.server});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onLongPress: () async {
        return server.deleteSingleMessage(chat.id);
      },
      child: Container(
        alignment: Alignment.centerRight,
        margin: const EdgeInsets.only(top: 20, left: 80, bottom: 15),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            ClipPath(
              clipper: UpperNipMessageClipperTwo(MessageType.send),
              child: Container(
                padding: const EdgeInsets.only(
                  top: 10,
                  bottom: 10,
                  left: 10,
                  right: 20,
                ),
                decoration: const BoxDecoration(color: Colors.blueGrey),
                child: Text(
                  chat.message,
                  style: const TextStyle(fontSize: 15),
                ),
              ),
            ),
            const SizedBox(height: 5),
            Text(
              textAlign: TextAlign.end,
              DateFormat("MMM d, yyyy hh:mm a").format(
                (chat.time?.toDate() ?? DateTime.now()),
              ),
              style: TextStyle(
                fontSize: 8.5,
                color: Colors.white.withOpacity(0.65),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ReceivedMessage extends StatelessWidget {
  final ChatModel chat;
  final ChatServer server;
  const ReceivedMessage({super.key, required this.chat, required this.server});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onLongPress: () async {
        return server.deleteSingleMessage(chat.id);
      },
      child: Padding(
        padding: const EdgeInsets.only(top: 20, left: 0, bottom: 15),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipPath(
              clipper: UpperNipMessageClipperTwo(MessageType.receive),
              child: Container(
                padding: const EdgeInsets.only(
                  top: 10,
                  bottom: 10,
                  left: 25,
                  right: 10,
                ),
                decoration: const BoxDecoration(
                  color: Colors.grey,
                ),
                child: Text(
                  chat.message,
                  style: const TextStyle(fontSize: 15),
                ),
              ),
            ),
            const SizedBox(height: 5),
            Text(
              textAlign: TextAlign.start,
              DateFormat("MMM d, yyyy hh:mm a").format(
                (chat.time?.toDate() ?? DateTime.now()),
              ),
              style: TextStyle(
                fontSize: 8.5,
                color: Colors.white.withOpacity(0.65),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
