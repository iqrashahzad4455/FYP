// ignore_for_file: public_member_api_docs, sort_constructors_first

import 'dart:ui';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:rockingequestrian/functions/models/user_model.dart';
import 'package:rockingequestrian/functions/user_server/user_server.dart';
import 'package:rockingequestrian/provider/user_provider.dart';
import 'package:rockingequestrian/utils/snackbar_utils.dart';

class Events extends StatefulWidget {
  const Events({super.key});

  @override
  State<Events> createState() => _EventsState();
}

class _EventsState extends State<Events> {
  late final UserProvider provider;
  final TextEditingController _eventDate = TextEditingController();
  final TextEditingController _eventTiming = TextEditingController();
  final TextEditingController _eventPlace = TextEditingController();
  final TextEditingController _eventorganizer = TextEditingController();
  final TextEditingController _bankDetails = TextEditingController();
  final TextEditingController _accountNo = TextEditingController();
  final TextEditingController _teamName = TextEditingController();
  final TextEditingController _teamCaptainName = TextEditingController();
  final TextEditingController _teamCaptainCnic = TextEditingController();
  final TextEditingController _totalMembers = TextEditingController();
  final TextEditingController _fullAddress = TextEditingController();
  final TextEditingController type = TextEditingController();
  final TextEditingController eventName = TextEditingController();

  @override
  void initState() {
    provider = context.read<UserProvider>();
    super.initState();
  }

  @override
  void dispose() {
    type.dispose();

    super.dispose();
  }

  Future<void> signup(showSnackBar) async {
    if (type.text.isEmpty) {
      return showSnackbar(
        context: context,
        message: "Select account type",
      );
    }
    return await UserServer()
        .signupUser(
            user: UserModel(
      type: type.text,
    ))
        .then((value) {
      return signup(showSnackBar(context: context, message: value.name));
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.blue,
        title: const Text("Event Form"),
      ),
      body: SingleChildScrollView(
        clipBehavior: Clip.antiAliasWithSaveLayer,
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.symmetric(horizontal: 30),
        child: Column(
          children: [
            const Padding(
              padding: EdgeInsets.only(top: 30),
              child: Text(
                "ORGANIZE AN EVENT",
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                  fontSize: 18,
                  decoration: TextDecoration.underline,
                ),
              ),
            ),
            const SizedBox(height: 20),
            FormTextField(
              controller: eventName,
              hint: "Enter Event Name",
            ),
            const SizedBox(height: 6),
            FormTextField(
              controller: type,
              // onTap: () {
              //   () async {
              //     showCupertinoDialog(
              //       context: context,
              //       builder: (context) {
              //         return CupertinoAlertDialog(
              //           title: const Text("Pick User Type"),
              //           actions: [
              //             MaterialButton(
              //               child: const Text("Cancel"),
              //               onPressed: () => Navigator.pop(context),
              //             ),
              //           ],
              //           content: Column(
              //             mainAxisSize: MainAxisSize.min,
              //             children: [
              //               EventTypeWidget(
              //                 onSelected: (String eventType) {
              //                   type.text = eventType;
              //                   return;
              //                 },
              //                 selectedEventType: type.text,
              //                 type: EventType.tentpeggiing,
              //               ),
              //               EventTypeWidget(
              //                 onSelected: (String eventType) {
              //                   type.text = eventType;
              //                   return;
              //                 },
              //                 selectedEventType: type.text,
              //                 type: EventType.horsebackarchery,
              //               ),
              //               EventTypeWidget(
              //                 onSelected: (String eventType) {
              //                   type.text = eventType;
              //                   return;
              //                 },
              //                 selectedEventType: type.text,
              //                 type: EventType.showjumping,
              //               ),
              //               EventTypeWidget(
              //                 onSelected: (String eventType) {
              //                   type.text = eventType;
              //                   return;
              //                 },
              //                 selectedEventType: type.text,
              //                 type: EventType.horseracing,
              //               ),
              //               EventTypeWidget(
              //                 onSelected: (String eventType) {
              //                   type.text = eventType;
              //                   return;
              //                 },
              //                 selectedEventType: type.text,
              //                 type: EventType.polo,
              //               ),
              //             ],
              //           ),
              //         );
              //       },
              //     );
              //   };
              // },
              hint: "Enter Event Type",
            ),
            const SizedBox(height: 6),
            FormTextField(
              isReadOnly: true,
              onTap: () async {
                final DateTime? date = await showDatePicker(
                  context: context,
                  firstDate: DateTime(
                    DateTime.now().subtract(const Duration(days: 2)).year,
                  ),
                  lastDate: DateTime(
                    DateTime.now().add(const Duration(days: 800)).year,
                  ),
                  initialDate: DateTime.now(),
                );
                // Check if User has picked a date or not
                if (date != null) {
                  _eventDate.text = "${date.month}/${date.day}/${date.year}";
                }
              },
              hint: "Enter Event Date",
              controller: _eventDate,
            ),
            const SizedBox(height: 6),
            FormTextField(
              isReadOnly: true,
              onTap: () async {
                final TimeOfDay? time = await showTimePicker(
                  context: context,
                  initialTime: TimeOfDay.now(),
                );
                // Check if User has picked a date or not
                if (time != null) {
                  // ignore: use_build_context_synchronously
                  _eventTiming.text = time.format(context);
                }
              },
              hint: "Enter Event Timing",
              controller: _eventTiming,
            ),
            const SizedBox(height: 6),
            FormTextField(
              hint: "Enter Event Place (Address)",
              controller: _eventPlace,
            ),
            const SizedBox(height: 6),
            FormTextField(
              hint: "Event Organizer Name",
              controller: _eventorganizer,
            ),
            const SizedBox(height: 6),
            FormTextField(
              hint: "Enter Bank Name",
              controller: _bankDetails,
            ),
            const SizedBox(height: 6),
            FormTextField(
              hint: "Enter Account Number / IBAN Number",
              controller: _accountNo,
            ),
            const SizedBox(height: 20),
            // const Text(
            //   "Participant Form",
            //   textAlign: TextAlign.center,
            //   style: TextStyle(
            //     fontSize: 22,
            //     fontWeight: FontWeight.w600,
            //     decoration: TextDecoration.underline,
            //   ),
            // ),
            // const SizedBox(height: 10),
            // FormTextField(
            //   hint: "Enter Team Name",
            //   controller: _teamName,
            // ),
            // const SizedBox(height: 6),
            // FormTextField(
            //   hint: "Enter Team Captain Name",
            //   controller: _teamCaptainName,
            // ),
            // const SizedBox(height: 6),
            // FormTextField(
            //   hint: "Enter Team Captain CNIC",
            //   controller: _teamCaptainCnic,
            // ),
            // const SizedBox(height: 6),
            // FormTextField(
            //   hint: "Enter Total Members",
            //   controller: _totalMembers,
            // ),
            // const SizedBox(height: 6),
            // FormTextField(
            //   hint: "Enter Full Address",
            //   controller: _fullAddress,
            // ),
            // const SizedBox(height: 20),
            // const Text(
            //   "Participant Information",
            //   textAlign: TextAlign.center,
            //   style: TextStyle(
            //     fontSize: 22,
            //     fontWeight: FontWeight.w600,
            //     decoration: TextDecoration.underline,
            //   ),
            // ),
            const SizedBox(height: 10),
            Padding(
              padding: const EdgeInsets.all(12.0),
              child: InkWell(
                onTap: () {
                  FirebaseFirestore.instance.collection('events').doc().set({
                    'name': eventName.text,
                    'eventType': type.text,
                    'date': _eventDate.text,
                    'time': _eventTiming.text,
                    'address': _eventPlace.text,
                    'organizer': _eventorganizer.text,
                    'bankDetails': _bankDetails.text,
                    'accountNumber': _accountNo.text,
                    'createdAt': DateTime.now(),
                    'createdBy': provider.user.email,
                    'createdByName': provider.user.name,
                    'rejected': false,
                    'approved': false,
                  }).then((a) {
                    Navigator.pop(context);
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text(
                            'Event has been Suceesfully Created! Wait for Approval'),
                        duration: Duration(seconds: 2),
                      ),
                    );
                  });
                },
                child: Container(
                  decoration: BoxDecoration(
                      color: Colors.blue,
                      borderRadius: BorderRadius.circular(20)),
                  height: 50,
                  width: 200,
                  child: const Center(child: Text('Submit')),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}

class FormTextField extends StatelessWidget {
  final String hint;
  final bool isReadOnly;
  final VoidCallback? onTap;
  final TextEditingController controller;
  const FormTextField({
    Key? key,
    required this.hint,
    this.isReadOnly = false,
    this.onTap,
    required this.controller,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return TextField(
      onTap: onTap,
      readOnly: isReadOnly,
      controller: controller,
      keyboardType: TextInputType.text,
      decoration: InputDecoration(
        filled: true,
        hintText: hint,
        hoverColor: Colors.blue,
        fillColor: Colors.white,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }
}

class EventTypeWidget extends StatelessWidget {
  final KeyEventType type;
  final String selectedEventType;
  final void Function(String) onSelected;
  const EventTypeWidget({
    Key? key,
    required this.type,
    required this.selectedEventType,
    required this.onSelected,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: RadioListTile(
        value: true,
        groupValue: type.name == selectedEventType,
        onChanged: (value) {
          onSelected(type.name);
          return Navigator.of(context).pop();
        },
        title: Text(type.name),
      ),
    );
  }
}
