import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:rockingequestrian/Home_Screen.dart';
import 'package:rockingequestrian/functions/models/post_model.dart';
import 'package:rockingequestrian/provider/user_provider.dart';

class DisplayUsersPosts extends StatefulWidget {
  const DisplayUsersPosts({super.key});

  @override
  State<DisplayUsersPosts> createState() => DisplayUsersPostsState();
}

class DisplayUsersPostsState extends State<DisplayUsersPosts>
    with AutomaticKeepAliveClientMixin {
  @override
  Widget build(BuildContext context) {
    super.build(context);
    final Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colors.white,
      body: SizedBox(
        width: size.width,
        height: size.height,
        child: StreamBuilder<List<PostModel>>(
          stream: context.read<UserProvider>().postServer.getPosts(),
          builder: (_, AsyncSnapshot<List<PostModel>> s) {
            // Check if Stream is Connected then check data
            if (s.connectionState == ConnectionState.active) {
              // Check if data is available
              if (s.hasData && s.data != null && s.data!.isNotEmpty) {
                return ListView.builder(
                  padding: EdgeInsets.zero,
                  itemCount: (s.data?.length ?? 0),
                  physics: const BouncingScrollPhysics(),
                  clipBehavior: Clip.antiAliasWithSaveLayer,
                  itemBuilder: (_, int index) {
                    return ClubCard(post: s.data!.elementAt(index));
                  },
                );
              }
              // show no data available
              return Center(
                child: Text(
                  "Posts not available",
                  textAlign: TextAlign.end,
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.black.withOpacity(0.75),
                  ),
                ),
              );
            }
            // show a loading indicator
            return const Center(
              child: CircularProgressIndicator.adaptive(),
            );
          },
        ),
      ),
    );
  }

  @override
  bool get wantKeepAlive => true;
}
