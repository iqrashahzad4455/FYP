import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:rockingequestrian/database/user_database.dart';
import 'package:rockingequestrian/functions/models/user_model.dart';
import 'package:rockingequestrian/functions/uploader_storage/uploader_storage.dart';
import 'package:rockingequestrian/functions/user_server/user_server.dart';
import 'package:rockingequestrian/utils/image_picker_utils.dart';
import 'package:rockingequestrian/utils/snackbar_utils.dart';
import 'package:rockingequestrian/widgets/avatar/user_avatar_widget.dart';

class EditProfile extends StatefulWidget {
  const EditProfile({super.key});

  @override
  State<EditProfile> createState() => _EditProfileState();
}

class _EditProfileState extends State<EditProfile> with WidgetsBindingObserver {
  /// Hold user value
  UserModel? user;

  /// Hold user profile Picker
  File? selectedProfile;

  /// Hold stream of user details changes
  late final StreamSubscription<UserModel> userStreamSubscription;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      userStreamSubscription = UserServer()
          .getUserById(UserDatabase.instance.getUID!)
          .listen((UserModel event) {
        _name.text = event.name;
        _bio.text = event.bio ?? "";
        _type.text = event.type;
        _password.text = event.password;
        if (mounted) {
          setState(() {
            user = event;
          });
        }
      });
    });
  }

  @override
  void dispose() {
    _bio.dispose();
    _type.dispose();
    _name.dispose();
    _password.dispose();
    userStreamSubscription.cancel();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  final TextEditingController _name = TextEditingController();
  final TextEditingController _password = TextEditingController();
  final TextEditingController _bio = TextEditingController();
  final TextEditingController _type = TextEditingController();

  /// Hold button enabled value
  bool isButtonEnabled = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.blue,
        title: const Text("Edit Profile"),
      ),
      body: SizedBox(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        child: SingleChildScrollView(
          clipBehavior: Clip.antiAliasWithSaveLayer,
          physics: const AlwaysScrollableScrollPhysics(),
          padding: EdgeInsets.symmetric(
            horizontal: MediaQuery.of(context).size.width * 0.05,
          ),
          child: Column(
            children: [
              const SizedBox(height: 40),
              GestureDetector(
                onTap: () async => ImagePickerUtils.instance
                    .pickCamera()
                    .then<void>((File? value) {
                  return setState(() {
                    selectedProfile = value;
                  });
                }),
                child: Stack(
                  children: [
                    if (selectedProfile == null)
                      UserAvatar(
                        width: 115,
                        height: 115,
                        url: user?.profileUrl,
                      )
                    else
                      ClipOval(
                        child: Image.file(
                          width: 115,
                          height: 115,
                          selectedProfile!,
                          fit: BoxFit.cover,
                        ),
                      ),
                    Positioned(
                      bottom: 0,
                      right: 0,
                      child: Container(
                        width: 32,
                        height: 32,
                        decoration: BoxDecoration(
                          color: Colors.green,
                          shape: BoxShape.circle,
                          border: Border.all(color: Colors.white),
                        ),
                        child: const Icon(
                          Icons.edit,
                          size: 18,
                          color: Colors.white,
                        ),
                      ),
                    )
                  ],
                ),
              ),
              const SizedBox(height: 40),
              TextField(
                controller: _name,
                decoration: InputDecoration(
                  fillColor: Colors.white,
                  filled: true,
                  hintText: "Full Name",
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ),
              const SizedBox(height: 8),
              TextField(
                enabled: false,
                readOnly: true,
                controller: TextEditingController(text: user?.email),
                decoration: InputDecoration(
                  fillColor: Colors.white,
                  filled: true,
                  hintText: "Change Your Email",
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: _password,
                decoration: InputDecoration(
                  fillColor: Colors.white,
                  filled: true,
                  hintText: "Change Your Password",
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: _bio,
                decoration: InputDecoration(
                  fillColor: Colors.white,
                  filled: true,
                  hintText: "Add Bio",
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              MaterialButton(
                height: 60,
                elevation: 1.0,
                color: Colors.white,
                minWidth: MediaQuery.of(context).size.width,
                clipBehavior: Clip.antiAliasWithSaveLayer,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                onPressed: isButtonEnabled
                    ? () async {
                        // mark button enabled to false
                        isButtonEnabled = false;
                        // Check if User details are null then don't do anything
                        if (user == null) {
                          return showSnackbar(
                            context: context,
                            message: "Not Allowed",
                          );
                        } else if (_name.text.isEmpty) {
                          return showSnackbar(
                            context: context,
                            message: "Enter your name",
                          );
                        } else if (_bio.text.isEmpty) {
                          return showSnackbar(
                            context: context,
                            message: "Enter your bio",
                          );
                        } else if (_password.text.isEmpty) {
                          return showSnackbar(
                            context: context,
                            message: "Enter your password",
                          );
                        }
                        String? url;
                        // Check if profile picture is selected then upload it into database
                        if (selectedProfile != null &&
                            selectedProfile!.path.isNotEmpty) {
                          url = await UploaderStorage()
                              .uploadProfile(selectedProfile!);
                        }
                        // Now update user details in firebase
                        final UserModel u = user!.copyWith(
                          bio: _bio.text,
                          name: _name.text,
                          password: _password.text,
                          profileUrl: url ?? user!.profileUrl,
                        );
                        // store detaiols in firebase
                        return UserServer()
                            .updateUser(
                                model: u, id: UserDatabase.instance.getUID!)
                            .then((_) {
                          // mark button enabled to true
                          isButtonEnabled = true;
                          return showSnackbar(
                            context: context,
                            message: "Changes are saved",
                          );
                        });
                      }
                    : () {},
                child: const Text("Save Changes"),
              ),
              const SizedBox(height: 12),
            ],
          ),
        ),
      ),
    );
  }
}
