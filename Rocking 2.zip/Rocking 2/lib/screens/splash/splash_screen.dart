import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:rockingequestrian/login_screen.dart';
import 'package:rockingequestrian/meta/settings_meta.dart';
import 'package:rockingequestrian/meta/theme_meta.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Future<void>.delayed(const Duration(milliseconds: 1250), () {
        Navigator.pushAndRemoveUntil<void>(
          context,
          CupertinoPageRoute(builder: (_) => const LoginScreen()),
          (_) => false,
        );
        return;
      });
      return;
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.of(context).size;
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: AppTheme.whiteBG,
      child: Scaffold(
        backgroundColor: Colors.white,
        body: SizedBox(
          width: size.width,
          height: size.height,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Spacer(),
              Image.asset(
                width: size.height * 0.27,
                height: size.height * 0.27,
                "images/logo.png",
              ),
              const SizedBox(height: 10),
              Text(
                AppSettings.appName,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                  color: Colors.black.withOpacity(0.7),
                ),
              ),
              const Spacer(),
            ],
          ),
        ),
      ),
    );
  }
}
