import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:rockingequestrian/database/user_database.dart';
import 'package:rockingequestrian/functions/chat_server/chat_server.dart';
import 'package:rockingequestrian/functions/models/user_model.dart';
import 'package:rockingequestrian/provider/user_provider.dart';
import 'package:rockingequestrian/search_user_chat.dart';
import 'package:rockingequestrian/widgets/chat_view_body/chat_view_body_widget.dart';
import 'package:rockingequestrian/widgets/guest_mode_listenable/guest_mode_listenable_widget.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  /// Create a Stream to Hold Sreach Button Viisbility
  final StreamController<bool> _showSearch = StreamController<bool>.broadcast();

  // Update Stream `_showSearch`
  void updateShowSearch(bool state) {
    // Make sure stream is not closed
    if (!_showSearch.isClosed) {
      _showSearch.sink.add(state);
    }
    return;
  }

  /// Hold List of Users Chat
  final List<UserModel> _usersChat = <UserModel>[];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Messages"),
        backgroundColor: Colors.blue,
        actions: [
          StreamBuilder(
            initialData: false,
            stream: _showSearch.stream,
            builder: (_, AsyncSnapshot<bool> snap) {
              // Check if data is true then show the button
              if (snap.data ?? false) {
                return IconButton(
                  onPressed: () {
                    showSearch<void>(
                      context: context,
                      delegate: CustomSearchDelegate(_usersChat),
                    );
                    return;
                  },
                  icon: const Icon(Icons.search),
                );
              }
              // Data is false so hide the button
              return const SizedBox.shrink();
            },
          ),
        ],
      ),
      body: SizedBox(
        width: double.infinity,
        height: double.infinity,
        child: GuestModeListenable(
          listenable: context.read<UserProvider>().userDB.listenable,
          guest: (_) => const Center(
            child: Text(
              "Please login to chat with users",
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.normal,
              ),
            ),
          ),
          child: (_) => FutureBuilder<List<UserModel>>(
            future: ChatServer(
              firestore: FirebaseFirestore.instance,
              userDatabase: UserDatabase.instance,
            ).getUsers(),
            builder: (_, AsyncSnapshot<List<UserModel>> snapshot) {
              if (snapshot.connectionState == ConnectionState.done) {
                if (snapshot.hasData && snapshot.data != null) {
                  // update stream value to true
                  updateShowSearch(true);
                  // Clear the old list and add new data
                  _usersChat.clear();
                  // Now add new data
                  _usersChat.addAll(snapshot.data ?? <UserModel>[]);
                  // Shhow List View
                  return ChatViewBody(users: snapshot.data);
                }
              }
              // update stream value to false
              updateShowSearch(false);
              return const Center(child: CircularProgressIndicator());
            },
          ),
        ),
      ),
    );
  }
}
