import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:rockingequestrian/functions/models/user_model.dart';
import 'package:rockingequestrian/utils/snackbar_utils.dart';
import 'package:rockingequestrian/widgets/avatar/user_avatar_widget.dart';

import 'Home_Screen.dart';

class Doctors extends StatefulWidget {
  const Doctors({super.key});

  @override
  State<Doctors> createState() => _DoctorsState();
}

class _DoctorsState extends State<Doctors> {
  final TextEditingController name = TextEditingController();
  final TextEditingController email = TextEditingController();
  final TextEditingController phone = TextEditingController();
  final TextEditingController dateinfo = TextEditingController();
  final TextEditingController docName = TextEditingController();

  String doctorUID = "";

  bool ischecked = false;
  bool ischecke = false;
  bool ischeckeema = false;
  bool ischeckepho = false;

  @override
  void dispose() {
    name.dispose();
    email.dispose();
    phone.dispose();
    docName.dispose();
    dateinfo.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.blue,
        title: const Text("Doctor Form"),
      ),
      body: SingleChildScrollView(
        clipBehavior: Clip.antiAliasWithSaveLayer,
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.only(top: 29, left: 15, right: 15),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  "For Person",
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 20),
                TextField(
                  controller: name,
                  decoration: InputDecoration(
                    fillColor: Colors.white,
                    filled: true,
                    hintText: "Name",
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 20,
                ),
                TextField(
                  controller: email,
                  decoration: InputDecoration(
                    fillColor: Colors.white,
                    filled: true,
                    hintText: "Email Address",
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 20,
                ),
                TextField(
                  controller: phone,
                  decoration: InputDecoration(
                    fillColor: Colors.white,
                    filled: true,
                    hintText: "Phone Number",
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 25,
                ),
                const Text(
                  "Appointment request",
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 20),
                TextField(
                  readOnly: true,
                  onTap: () {
                    showDoctorsBottomSheet(
                      context,
                      onDoctorSelected: (String doctorName, String id) {
                        docName.text = doctorName;
                        doctorUID = id;
                      },
                    );
                  },
                  controller: docName,
                  decoration: InputDecoration(
                    fillColor: Colors.white,
                    filled: true,
                    hintText: "Select Doctor",
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                TextFormField(
                  controller: dateinfo,
                  onTap: () async {
                    final DateTime? date = await showDatePicker(
                      context: context,
                      firstDate: DateTime(1947),
                      lastDate: DateTime(2025),
                      initialDate: DateTime.now(),
                    );
                    // Check if User has picked a date or not
                    if (date != null) {
                      dateinfo.text = "${date.month}/${date.day}/${date.year}";
                    }
                  },
                  decoration: InputDecoration(
                    fillColor: Colors.white,
                    filled: true,
                    hintText: "dd/mm/yyyy",
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 25,
                ),
                Row(
                  children: [
                    Checkbox(
                        activeColor: Colors.black,
                        value: ischecked,
                        onChanged: (val) {
                          setState(() {
                            ischecked = val!;
                          });
                        }),
                    const Text(
                      "Morning",
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(
                      width: 25,
                    ),
                    Checkbox(
                        activeColor: Colors.black,
                        value: ischecke,
                        onChanged: (val) {
                          setState(() {
                            ischecke = val!;
                          });
                        }),
                    const Text(
                      "Afternoon",
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                const SizedBox(
                  height: 25,
                ),
                const Text(
                  "Confirmation requested by",
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(
                  height: 25,
                ),
                Row(
                  children: [
                    Checkbox(
                        activeColor: Colors.black,
                        value: ischeckeema,
                        onChanged: (val) {
                          setState(() {
                            ischeckeema = val!;
                          });
                        }),
                    const Text(
                      "Email",
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(
                      width: 25,
                    ),
                    Checkbox(
                        activeColor: Colors.black,
                        value: ischeckepho,
                        onChanged: (val) {
                          setState(() {
                            ischeckepho = val!;
                          });
                        }),
                    const Text(
                      "Phone call",
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                InkWell(
                  onTap: () async {
                    if (docName.text.isEmpty) {
                      return showSnackbar(
                        context: context,
                        message: "Select a Doctor",
                      );
                    }
                    if (name.text.isEmpty) {
                      return showSnackbar(
                        context: context,
                        message: "Enter your name",
                      );
                    }
                    if (phone.text.isEmpty) {
                      return showSnackbar(
                        context: context,
                        message: "Enter your phone no.",
                      );
                    }
                    if (dateinfo.text.isEmpty) {
                      return showSnackbar(
                        context: context,
                        message: "Select Date",
                      );
                    }
                    await FirebaseFirestore.instance
                        .collection('doctors')
                        .doc()
                        .set({
                      'name': name.text,
                      'email': email.text,
                      'phone': phone.text,
                      'date': dateinfo.text,
                      'morning': ischecked,
                      'afternoon': ischecked,
                      'doctor_id': doctorUID,
                      'doctor_name': docName.text,
                      'confirmByEmail': ischeckeema,
                      'confirmByPhone': ischeckepho
                    }).then((value) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content:
                              Text('Your Information Successfully Submitted'),
                          duration: Duration(seconds: 2),
                        ),
                      );
                      Navigator.pushAndRemoveUntil<void>(
                        context,
                        CupertinoPageRoute(builder: (_) => const HomeScreen()),
                        (_) => false,
                      );
                    });
                  },
                  child: Center(
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Container(
                        decoration: BoxDecoration(
                            color: Colors.blue,
                            borderRadius: BorderRadius.circular(20)),
                        height: 50,
                        width: 200,
                        child: const Center(child: Text('Submit')),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

void showDoctorsBottomSheet(
  BuildContext context, {
  required void Function(String doctorName, String id) onDoctorSelected,
}) {
  showModalBottomSheet<void>(
    elevation: 5.0,
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.white,
    clipBehavior: Clip.antiAliasWithSaveLayer,
    builder: (context) {
      return _ShowDoctorBottomModelSheet(onDoctorSelected: onDoctorSelected);
    },
  );
}

class _ShowDoctorBottomModelSheet extends StatefulWidget {
  final void Function(String doctorName, String id) onDoctorSelected;
  const _ShowDoctorBottomModelSheet({required this.onDoctorSelected});

  @override
  State<_ShowDoctorBottomModelSheet> createState() =>
      __ShowDoctorBottomModelSheetState();
}

class __ShowDoctorBottomModelSheetState
    extends State<_ShowDoctorBottomModelSheet> {
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: MediaQuery.of(context).size.height * 0.75,
      child: FutureBuilder<List<UserModel>>(
        future: FirebaseFirestore.instance
            .collection("users")
            .where("type", isEqualTo: "Doctor")
            .get()
            .then<List<UserModel>>((QuerySnapshot<Map<String, dynamic>> value) {
          return List<UserModel>.from(
            value.docs.map<UserModel>(
              (QueryDocumentSnapshot<Map<String, dynamic>> e) {
                return UserModel.fromMap(e.data());
              },
            ),
          );
        }),
        builder: (_, AsyncSnapshot<List<UserModel>> s) {
          if (s.hasData && s.data != null && s.data!.isNotEmpty) {
            return Column(
              children: [
                const SizedBox(height: 15),
                Text(
                  "Select a Doctor",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.w600,
                    color: Colors.black.withOpacity(0.75),
                  ),
                ),
                const SizedBox(height: 15),
                Expanded(
                  child: ListView.builder(
                    itemCount: s.data?.length ?? 0,
                    clipBehavior: Clip.antiAliasWithSaveLayer,
                    physics: const AlwaysScrollableScrollPhysics(),
                    padding: const EdgeInsets.symmetric(horizontal: 15),
                    itemBuilder: (_, int index) {
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: GestureDetector(
                          onTap: () {
                            widget.onDoctorSelected(
                              s.data![index].name,
                              s.data![index].email,
                            );
                            return Navigator.of(context).pop();
                          },
                          child: Card(
                            elevation: 4.0,
                            color: Colors.white,
                            surfaceTintColor: Colors.white,
                            clipBehavior: Clip.antiAliasWithSaveLayer,
                            child: Padding(
                              padding: const EdgeInsets.all(5.0),
                              child: Row(
                                children: [
                                  const SizedBox(width: 6),
                                  UserAvatar(
                                    width: 60,
                                    height: 60,
                                    url: s.data![index].profileUrl,
                                  ),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: Text(
                                      s.data![index].name,
                                      textAlign: TextAlign.start,
                                      style: TextStyle(
                                        fontSize: 18,
                                        color: Colors.black.withOpacity(0.7),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            );
          } else if (s.connectionState == ConnectionState.done) {
            return const Center(
              child: Text("Doctors not available"),
            );
          } else {
            return const Center(
              child: CircularProgressIndicator.adaptive(),
            );
          }
        },
      ),
    );
  }
}
