import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:rockingequestrian/add_new_post.dart';
import 'package:rockingequestrian/chat_screen.dart';
import 'package:rockingequestrian/comment_screen.dart';
import 'package:rockingequestrian/creat_event.dart';
import 'package:rockingequestrian/database/user_database.dart';
import 'package:rockingequestrian/display_posts.dart';
import 'package:rockingequestrian/doctorpage.dart';
import 'package:rockingequestrian/edit-profile.dart';
import 'package:rockingequestrian/events.dart';
import 'package:rockingequestrian/functions/extensions/string/string.extensions.fucntions.dart';
import 'package:rockingequestrian/functions/models/notification_model.dart';
import 'package:rockingequestrian/functions/models/post_model.dart';
import 'package:rockingequestrian/functions/models/user_model.dart';
import 'package:rockingequestrian/functions/post_server/post_server.dart';
import 'package:rockingequestrian/lecturespage.dart';
import 'package:rockingequestrian/login_screen.dart';
import 'package:rockingequestrian/meta/settings_meta.dart';
import 'package:rockingequestrian/meta/theme_meta.dart';
import 'package:rockingequestrian/notoficationpage.dart';
import 'package:rockingequestrian/productpage.dart';
import 'package:rockingequestrian/provider/user_provider.dart';
import 'package:rockingequestrian/types/user_type.dart';
import 'package:rockingequestrian/user-profile.dart';
import 'package:rockingequestrian/widgets/avatar/user_avatar_widget.dart';
import 'package:rockingequestrian/widgets/guest_mode_listenable/guest_mode_listenable_widget.dart';
import 'package:share/share.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int currentNavIndex = 0;
  final PageController controller = PageController();

  // Cretae an Instance Of UserDatabase
  final UserDatabase _userDatabase = UserDatabase.instance;

  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      // Initialize UserProvider initial Function
      return context.read<UserProvider>().initialize();
    });
    super.initState();
  }

  void openchatscreen() {
    Navigator.push<void>(
      context,
      CupertinoPageRoute(
        builder: ((context) => const ChatScreen()),
      ),
    );
  }

  final List<Widget> _screens = const <Widget>[
    DisplayUsersPosts(),
    AddNewPost(),
    NotificationPage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0.0,
        leadingWidth: 45,
        backgroundColor: Colors.blue,
        systemOverlayStyle: AppTheme.brownBG,
        title: Row(
          children: [
            Consumer<UserProvider>(
              builder: (_, UserProvider pro, __) {
                return UserAvatar(
                  height: 35,
                  width: 35,
                  url: pro.user.profileUrl,
                );
              },
            ),
            const SizedBox(width: 6.0),
            const Text(
              AppSettings.appName,
              style: TextStyle(
                color: Colors.black,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
        leading: Theme(
          data: Theme.of(context).copyWith(
            dividerTheme: DividerThemeData(
              color: Colors.black.withOpacity(0.5),
            ),
            iconTheme: const IconThemeData(color: Colors.black),
            textTheme: const TextTheme().apply(bodyColor: Colors.black),
          ),
          child: GuestModeListenable(
            listenable: _userDatabase.listenable,
            child: (Map<String, dynamic>? data) {
              final bool isLoggedIn = data?.isNotEmpty ?? false;
              return PopupMenuButton<int>(
                position: PopupMenuPosition.under,
                icon: const Icon(Icons.menu, color: Colors.black),
                itemBuilder: (BuildContext context) => <PopupMenuEntry<int>>[
                  if (isLoggedIn)
                    PopupMenuItem(
                      padding: const EdgeInsets.only(left: 5),
                      onTap: () async {
                        final navigator = Navigator.of(context);
                        await Future.delayed(Duration.zero);
                        return navigator.push<void>(
                          CupertinoPageRoute(
                            builder: (_) => const EditProfile(),
                          ),
                        );
                      },
                      child: Row(
                        children: [
                          Consumer<UserProvider>(
                            builder: (_, UserProvider pro, __) {
                              return UserAvatar(
                                width: 32,
                                height: 32,
                                url: pro.user.profileUrl,
                              );
                            },
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              _userDatabase.getName ?? "Error",
                              maxLines: 1,
                              style: const TextStyle(
                                color: Colors.black,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  if (isLoggedIn) const PopupMenuDivider(),
                  if (isLoggedIn)
                    PopupMenuItem(
                      value: 1,
                      child: const Text(
                        'Lectures',
                        style: TextStyle(
                          fontSize: 17,
                          color: Colors.black,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      onTap: () async {
                        final navigator = Navigator.of(context);
                        await Future.delayed(Duration.zero);
                        navigator.push(
                          CupertinoPageRoute(builder: (_) => const Lectures()),
                        );
                      },
                    ),
                  if (isLoggedIn) const PopupMenuDivider(),
                  if (isLoggedIn)
                    PopupMenuItem(
                      onTap: () async {
                        final navigator = Navigator.of(context);
                        await Future.delayed(Duration.zero);
                        navigator.push(
                          CupertinoPageRoute(
                            builder: (_) => const UpComminEvents(),
                          ),
                        );
                      },
                      value: 2,
                      child: const Text(
                        'Events',
                        style: TextStyle(
                          fontSize: 17,
                          color: Colors.black,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  if (isLoggedIn) const PopupMenuDivider(),
                  if (isLoggedIn)
                    PopupMenuItem(
                      onTap: () async {
                        final navigator = Navigator.of(context);
                        await Future.delayed(Duration.zero);
                        navigator.push(
                          CupertinoPageRoute(builder: (_) => const Product()),
                        );
                      },
                      value: 2,
                      child: const Text(
                        'Products',
                        style: TextStyle(
                          fontSize: 17,
                          color: Colors.black,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  if (isLoggedIn) const PopupMenuDivider(),
                  if (isLoggedIn)
                    PopupMenuItem(
                      onTap: () async {
                        final navigator = Navigator.of(context);
                        await Future.delayed(Duration.zero);
                        navigator.push(
                          CupertinoPageRoute(builder: (_) => const Doctors()),
                        );
                      },
                      value: 3,
                      child: const Text(
                        'Doctors',
                        style: TextStyle(
                          fontSize: 17,
                          color: Colors.black,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  if (isLoggedIn) const PopupMenuDivider(),
                  if (isLoggedIn)
                    PopupMenuItem(
                      onTap: () async {
                        final navigator = Navigator.of(context);
                        await Future.delayed(Duration.zero);
                        navigator.push(
                          CupertinoPageRoute(builder: (_) => const Events()),
                        );
                      },
                      value: 4,
                      child: const Text(
                        'Create an event',
                        style: TextStyle(
                          fontSize: 17,
                          color: Colors.black,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  if (isLoggedIn) const PopupMenuDivider(),
                  if (isLoggedIn)
                    PopupMenuItem(
                      value: 5,
                      onTap: () => _userDatabase.logout().then<void>((_) {
                        return Navigator.push<void>(
                          context,
                          CupertinoPageRoute(
                            builder: (_) => const LoginScreen(),
                          ),
                        );
                      }),
                      child: const Text(
                        'Logout',
                        style: TextStyle(
                          fontSize: 17,
                          color: Colors.black,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                ],
              );
            },
          ),
        ),
        actionsIconTheme: const IconThemeData(color: Colors.black),
      ),
      //Add bottom navigationbar,
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.blue,
        currentIndex: currentNavIndex,
        onTap: (int index) {
          currentNavIndex = index;
          setState(() {});
          controller.jumpToPage(index);
        },
        unselectedItemColor: Colors.black.withOpacity(0.65),
        selectedItemColor: Colors.black.withOpacity(0.95),
        items: const [
          BottomNavigationBarItem(
            label: "Home",
            icon: Icon(CupertinoIcons.house),
            activeIcon: Icon(CupertinoIcons.house_fill),
          ),
          BottomNavigationBarItem(
            label: "Add Post",
            icon: Icon(Icons.add_circle_outline),
            activeIcon: Icon(CupertinoIcons.add_circled_solid),
          ),
          BottomNavigationBarItem(
            label: "Notification",
            icon: Icon(CupertinoIcons.bell),
            activeIcon: Icon(CupertinoIcons.bell_fill),
          )
        ],
      ),
      //Use page view widget move one screen to other screen,
      body: PageView.builder(
        onPageChanged: (int index) {
          currentNavIndex = index;
          setState(() {});
        },
        controller: controller,
        itemCount: _screens.length,
        itemBuilder: (_, int index) {
          return _screens.elementAt(index);
        },
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Color.fromARGB(255, 55, 155, 236),
        foregroundColor: Colors.black,
        hoverColor: Color.fromARGB(255, 15, 121, 207),
        child: const Icon(CupertinoIcons.chat_bubble),
        onPressed: () => openchatscreen(),
      ),
    );
  }
}

class ClubCard extends StatelessWidget {
  final PostModel post;
  final bool enableProfileTab;
  const ClubCard({super.key, required this.post, this.enableProfileTab = true});

  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.of(context).size;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const SizedBox(width: 6.0),
            GestureDetector(
              onTap: enableProfileTab
                  ? () {
                      if (enableProfileTab) {
                        Navigator.push<void>(
                          context,
                          CupertinoPageRoute(
                            builder: (_) => UserProfileView(
                              user: UserModel(
                                name: post.postBy.nullSafe,
                                email: post.userID.nullSafe,
                                type: post.userType?.name ?? "",
                              ),
                            ),
                          ),
                        );
                      }
                    }
                  : null,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(30),
                child: Image.asset(height: 50, "images/logo.png"),
              ),
            ),
            const SizedBox(width: 10.0),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    post.postBy ?? "Unknown",
                    style: const TextStyle(
                      fontSize: 16,
                      color: Colors.black,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    post.userType?.name ?? UserTypes.none.name,
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.normal,
                      color: Colors.black.withOpacity(0.75),
                    ),
                  ),
                ],
              ),
            ),
            PopupMenuButton(
              itemBuilder: (_) => [
                if (post.userID.isSame(UserDatabase.instance.getUID ?? ""))
                  PopupMenuItem(
                    child: const Text("Delete"),
                    onTap: () {
                      PostServer().deletePost(post);
                    },
                  ),
                PopupMenuItem(
                  child: const Text("Share"),
                  onTap: () {
                    Share.share(
                      "https://play.google.com/store/app/details?id=com.instructivetech.testapp",
                    );
                  },
                ),
                const PopupMenuItem(
                  child: Text("Report"),
                )
              ],
            )
          ],
        ),
        if (post.content?.isNotEmpty ?? false) const SizedBox(height: 8),
        if (post.content?.isNotEmpty ?? false)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14.0),
            child: Text(
              post.content!,
              textAlign: TextAlign.start,
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w500,
                color: Colors.black.withOpacity(0.75),
              ),
            ),
          ),
        const SizedBox(height: 2),
        if (post.media?.isNotEmpty ?? false)
          if (post.media!.length > 1)
            Wrap(
              spacing: 6.0,
              runSpacing: 6.0,
              alignment: WrapAlignment.center,
              runAlignment: WrapAlignment.center,
              children: post.media!.map<Widget>((String url) {
                return InteractiveViewer(
                  minScale: 0.1,
                  maxScale: 5.0,
                  child: CachedNetworkImage(
                    fit: BoxFit.fitWidth,
                    imageUrl: url.nullSafe,
                    colorBlendMode: BlendMode.darken,
                    width: (size.width / (increaseWidth(url) ? 1 : 2.03)),
                    height: increaseWidth(url) ? size.height * 0.35 : null,
                  ),
                );
              }).toList(),
            )
          else
            InteractiveViewer(
              minScale: 0.1,
              maxScale: 5.0,
              child: CachedNetworkImage(
                imageUrl: post.media?.first ?? "",
                fit: BoxFit.fitWidth,
                colorBlendMode: BlendMode.darken,
                width: size.width,
              ),
            ),
        const SizedBox(height: 2),
        Divider(thickness: 0.5, color: Colors.black.withOpacity(0.5)),
        Row(
          children: [
            const SizedBox(width: 6.0),
            IconButton(
              iconSize: 26,
              onPressed: () async {
                final UserProvider provider = context.read<UserProvider>();
                // Hold Post Likes details
                final List<String> likes = post.likesID ?? <String>[];
                // Check if user already liked this post or not
                if (isPostLiked) {
                  likes.remove(UserDatabase.instance.getUID);
                } else {
                  likes.add(UserDatabase.instance.getUID ?? "");
                }
                // Now add like into database
                await FirebaseFirestore.instance
                    .collection('posts')
                    .doc(post.postID)
                    .update(post.copyWith(likesID: likes).updatePost());
                // send notification the user
                provider.userServer.storeNotification(
                  userId: post.userID ?? "",
                  notification: NotificationModel(
                    name: provider.user.name,
                    title: "Liked your post",
                    userProfileUrl: provider.user.profileUrl,
                  ),
                );
              },
              color: Colors.black.withOpacity(0.75),
              icon: Icon(
                isPostLiked ? CupertinoIcons.heart_fill : CupertinoIcons.heart,
                color: isPostLiked ? Colors.red : Colors.black.withOpacity(0.7),
              ),
            ),
            Text(
              (post.likesID?.length ?? 0).toString(),
              textAlign: TextAlign.start,
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w500,
                color: Colors.black.withOpacity(0.75),
              ),
            ),
            IconButton(
              iconSize: 26,
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => TestMe(post: post),
                  ),
                );
              },
              color: Colors.black.withOpacity(0.75),
              icon: const Icon(CupertinoIcons.chat_bubble),
            ),
            const Spacer(),
          ],
        ),
        Divider(thickness: 0.8, color: Colors.black.withOpacity(0.5)),
      ],
    );
  }

  bool get isPostLiked {
    try {
      return post.likesID != null &&
          post.likesID!.contains(UserDatabase.instance.getUID);
    } catch (e) {
      return false;
    }
  }

  bool increaseWidth(String url) {
    if (post.media?.isNotEmpty ?? false) {
      if (post.media!.length > 1) {
        if (post.media!.last.isSame(url)) {
          if (!(post.media!.length % 2 == 0)) {
            // Length is odd so need to increase width
            return true;
          }
        }
      }
    }
    return false;
  }
}
