import 'package:flutter/material.dart';
import 'package:timeago/timeago.dart' as time_ago;
import 'package:rockingequestrian/functions/models/notification_model.dart';
import 'package:rockingequestrian/widgets/avatar/user_avatar_widget.dart';

class NotificationCard extends StatelessWidget {
  final NotificationModel notification;
  const NotificationCard({super.key, required this.notification});

  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.of(context).size;
    return SizedBox(
      child: Row(
        children: [
          UserAvatar(
            width: 55,
            height: 55,
            url: notification.userProfileUrl,
          ),
          SizedBox(width: size.width * 0.04),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  notification.name,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                SizedBox(height: size.height * 0.005),
                Text(
                  "${notification.title} . ${time_ago.format(
                    (notification.time?.toDate() ?? DateTime.now()),
                    locale: "en_short",
                  )}",
                  style: const TextStyle(fontSize: 15),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
