import 'dart:ui';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:rockingequestrian/addTeamMembers.dart';
import 'package:rockingequestrian/utils/snackbar_utils.dart';

class AddParticipant extends StatefulWidget {
  final String eventID;
  const AddParticipant({super.key, required this.eventID});

  @override
  State<AddParticipant> createState() => _AddParticipantState();
}

class _AddParticipantState extends State<AddParticipant> {
  final TextEditingController _teamName = TextEditingController();
  final TextEditingController _teamCaptainName = TextEditingController();

  final TextEditingController _totalMembers = TextEditingController();
  final TextEditingController _fullAddress = TextEditingController();

  @override
  void dispose() {
    _teamName.dispose();
    _teamCaptainName.dispose();
    _totalMembers.dispose();
    _fullAddress.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.brown,
      appBar: AppBar(
        backgroundColor: Colors.brown,
        title: const Text("Event Form"),
      ),
      body: SingleChildScrollView(
        clipBehavior: Clip.antiAliasWithSaveLayer,
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.symmetric(horizontal: 30),
        child: Column(
          children: [
            const Padding(
              padding: EdgeInsets.only(top: 30),
              child: Text(
                "Participant Form",
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                  fontSize: 18,
                  decoration: TextDecoration.underline,
                ),
              ),
            ),
            const SizedBox(height: 20),
            FormTextField(
              controller: _teamName,
              hint: "Team Name",
            ),
            const SizedBox(height: 6),
            FormTextField(
              hint: "Team Captain",
              controller: _teamCaptainName,
            ),
            const SizedBox(height: 6),
            FormTextField(
              hint: "Total Memebers",
              controller: _totalMembers,
            ),
            const SizedBox(height: 6),
            FormTextField(
              hint: "Full Address",
              controller: _fullAddress,
            ),
            const SizedBox(height: 30),
            Padding(
              padding: const EdgeInsets.all(12.0),
              child: InkWell(
                onTap: () async {
                  if (_teamName.text.isEmpty) {
                    return showSnackbar(
                      context: context,
                      message: "Type Team Name",
                    );
                  } else if (_teamCaptainName.text.isEmpty) {
                    return showSnackbar(
                      context: context,
                      message: "Type Team Captain Name",
                    );
                  } else if (_totalMembers.text.isEmpty) {
                    return showSnackbar(
                      context: context,
                      message: "Type Team Members",
                    );
                  } else if (_fullAddress.text.isEmpty) {
                    return showSnackbar(
                      context: context,
                      message: "Type Full Address",
                    );
                  }
                  final navigator = Navigator.of(context);
                  navigator.push(CupertinoPageRoute(
                    builder: (_) => AddTeamMember(
                      eventID: widget.eventID,
                      address: _fullAddress.text,
                      captain: _teamCaptainName.text,
                      members: _totalMembers.text,
                      teamName: _teamName.text,
                    ),
                  ));
                },
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  height: 60,
                  width: 250,
                  child: const Center(child: Text('Next')),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}

class FormTextField extends StatelessWidget {
  final String hint;
  final bool isReadOnly;
  final VoidCallback? onTap;
  final TextEditingController controller;
  const FormTextField({
    Key? key,
    required this.hint,
    this.isReadOnly = false,
    this.onTap,
    required this.controller,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return TextField(
      onTap: onTap,
      readOnly: isReadOnly,
      controller: controller,
      keyboardType: TextInputType.text,
      decoration: InputDecoration(
        filled: true,
        hintText: hint,
        hoverColor: Colors.blue,
        fillColor: Colors.white,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }
}

class EventTypeWidget extends StatelessWidget {
  final KeyEventType type;
  final String selectedEventType;
  final void Function(String) onSelected;
  const EventTypeWidget({
    Key? key,
    required this.type,
    required this.selectedEventType,
    required this.onSelected,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: RadioListTile(
        value: true,
        groupValue: type.name == selectedEventType,
        onChanged: (value) {
          onSelected(type.name);
          return Navigator.of(context).pop();
        },
        title: Text(type.name),
      ),
    );
  }
}
