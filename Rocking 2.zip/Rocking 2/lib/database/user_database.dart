import 'dart:developer';
import 'package:flutter/foundation.dart';
import 'package:get_storage/get_storage.dart';

@immutable
class UserDatabase {
  static UserDatabase? _instance;

  /// Privatised the constructor
  UserDatabase._internal() {
    if (kDebugMode) {
      log("UserDatabase constructor called");
    }
  }

  /// Provide a instance whenever it's needed
  static UserDatabase get instance {
    // Provide a instance if not initialized yet
    _instance ??= UserDatabase._internal();
    return _instance!;
  }

  static const String container = "user_db";

  final GetStorage _db = GetStorage(container);

  // Listen to Database Changes
  void listen(void Function() value) {
    _db.listen(value);
  }

  Future<void> storeUserDetails({
    required String uid,
    required String pwd,
  }) async {
    await _db.write(_uidKey, uid);
    return await _db.write(_pwdKey, pwd);
  }

  Future<void> storeName({required String name}) {
    return _db.write(_nameKey, name);
  }

  ValueStorage<Map<String, dynamic>> get listenable {
    return _db.listenable;
  }

  Future<void> logout() => _db.erase();

  String? get getUID => _db.read<String?>(_uidKey);
  String? get getPWD => _db.read<String?>(_pwdKey);
  String? get getName => _db.read<String?>(_nameKey);

  static const String _uidKey = "uid_key";
  static const String _pwdKey = "pwd_key";
  static const String _nameKey = "name_key";
}
