import 'dart:developer';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:image_picker/image_picker.dart';

@immutable
class ImagePickerUtils {
  /// Create an Instance
  static ImagePickerUtils? _instance;

  /// Privatised the constructor
  ImagePickerUtils._internal() {
    if (kDebugMode) {
      log("ImagePickerUtils constructor called");
    }
  }

  /// Provide a instance whenever it's needed
  static ImagePickerUtils get instance {
    // Provide a instance if not initialized yet
    _instance ??= ImagePickerUtils._internal();
    return _instance!;
  }

  /// Create a instance of `ImagePicker`
  final ImagePicker _picker = ImagePicker();

  /// `pickGallery` function
  ///
  /// Pick Image from Gallery. If user didn't pick the image it will return null
  Future<File?> pickGallery() async {
    // Hold Image Path
    XFile? xfile;
    // Try to pick image from gallery
    xfile = await _picker.pickImage(source: ImageSource.gallery);
    // Make sure xfile is not null and empty
    if (xfile != null && xfile.path.isNotEmpty) {
      //return the image as it is
      return Future<File?>.value(File(xfile.path));
    }
    // return Null bacuse user didn't pick image image
    return Future<File?>.value(null);
  }

  /// `pickCamera` function
  ///
  /// click Image from Camera. If user didn't click the image it will return null
  Future<File?> pickCamera({
    int? width,
    int? height,
    int? quality,
    bool useCompress = true,
  }) async {
    // Hold Image Path
    XFile? xfile;
    // Try to click image from Camera
    xfile = await _picker.pickImage(source: ImageSource.camera);
    // Make sure xfile is not null and empty
    if (xfile != null && xfile.path.isNotEmpty) {
      //return the image as it is
      return Future<File?>.value(File(xfile.path));
    }
    // return Null bacuse user didn't click image
    return Future<File?>.value(null);
  }

  /// `fileName` function
  ///
  /// check file and return it's name
  String fileName(File file) {
    // make sure file path is valid
    if (file.path.isNotEmpty && file.path.contains("/")) {
      return "${DateTime.now().microsecondsSinceEpoch}_${file.path.split("/").last}";
    } else {
      // return path because file path is not valid
      return file.path;
    }
  }
}
