import 'package:flutter/material.dart';

void showSnackbar({
  required String message,
  required BuildContext context,
}) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
    content: Text(message),
    backgroundColor: Colors.blue,
    duration: const Duration(milliseconds: 1500),
  ));
  return;
}
