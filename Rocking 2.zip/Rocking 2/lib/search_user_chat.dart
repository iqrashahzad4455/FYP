import 'package:flutter/material.dart';
import 'package:rockingequestrian/functions/models/user_model.dart';
import 'package:rockingequestrian/widgets/chat_view_body/chat_view_body_widget.dart';

class CustomSearchDelegate extends SearchDelegate {
  final List<UserModel> users;
  CustomSearchDelegate(this.users);

  @override
  List<Widget>? buildActions(BuildContext context) {
    return [
      IconButton(
        onPressed: () {},
        color: Colors.black.withOpacity(0.75),
        icon: const Icon(Icons.clear),
      ),
    ];
  }

  @override
  Widget? buildLeading(BuildContext context) {
    return IconButton(
      onPressed: () {
        return close(context, null);
      },
      color: Colors.black.withOpacity(0.75),
      icon: const Icon(Icons.arrow_back_rounded),
    );
  }

  @override
  Widget buildResults(BuildContext context) {
    /// Check if user name is or full name is in the list of not
    List<UserModel> searched = <UserModel>[];
    // Search now
    searched = users.where((i) {
      if (i.name.toLowerCase() == query.toLowerCase()) {
        return true;
      } else if (i.email.toLowerCase() == query.toLowerCase()) {
        return true;
      }
      return false;
    }).toList();
    // Now return a listview
    return ChatViewBody(users: searched);
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    /// Check if user name is or full name is in the list of not
    List<UserModel> searched = <UserModel>[];
    // Search now
    searched = users.where((i) {
      if (i.name.toLowerCase().contains(query.toLowerCase())) {
        return true;
      } else if (i.email.toLowerCase().contains(query.toLowerCase())) {
        return true;
      }
      return false;
    }).toList();
    // Now return a listview
    return ChatViewBody(users: searched);
  }
}
