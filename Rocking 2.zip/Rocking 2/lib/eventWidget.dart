import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../events.dart';

class AccountManagementWidget extends StatefulWidget {
  String eventName;
  String eventID;
  String eventDate;
  String eventAddress;
  String eventType;
  String eventTime;
  String eventOragnizer;
  String bankDetails;
  String accountNumber;
  String createdBy;
  String createdByName;
  Timestamp createdDate;
  bool approved;

  AccountManagementWidget(
      {Key? key,
      required this.accountNumber,
      required this.approved,
      required this.bankDetails,
      required this.createdBy,
      required this.eventID,
      required this.createdByName,
      required this.createdDate,
      required this.eventAddress,
      required this.eventDate,
      required this.eventName,
      required this.eventOragnizer,
      required this.eventTime,
      required this.eventType})
      : super(key: key);

  @override
  State<AccountManagementWidget> createState() =>
      _AccountManagementWidgetState();
}

class _AccountManagementWidgetState extends State<AccountManagementWidget> {
  double lat = 0, lang = 0;

  @override
  void initState() {}

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(40, 27, 18, 0),
          child: Stack(
            children: [
              Card(
                color: Colors.white,
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      // SingleText(
                      //   title: 'Event Created By',
                      //   subtitle: widget.createdByName,
                      // ),
                      SingleText(
                        title: 'Event Name',
                        subtitle: widget.eventName,
                      ),

                      SingleText(
                        title: 'Event Type',
                        subtitle: widget.eventType,
                      ),
                      SingleText(
                        title: 'Event Date',
                        subtitle: widget.eventDate,
                      ),
                      SingleText(
                        title: 'Event Time',
                        subtitle: widget.eventTime,
                      ),
                      SingleText(
                        title: 'Event Place',
                        subtitle: widget.eventAddress,
                      ),
                      SingleText(
                        title: 'Event Organizer',
                        subtitle: widget.eventOragnizer,
                      ),
                      // SingleText(
                      //   title: 'Bank Details',
                      //   subtitle: widget.bankDetails,
                      // ),
                      // SingleText(
                      //   title: 'Account Number',
                      //   subtitle: widget.accountNumber,
                      // ),

                      // widget.expanded
                      //     ? Padding(
                      //         padding: const EdgeInsets.all(8.0),
                      //         child: SizedBox(
                      //             height: 125,
                      //             width: 255,
                      //             child: OSMFlutter(
                      //               controller: controller,
                      //               trackMyPosition: false,
                      //               initZoom: 12,
                      //               minZoomLevel: 8,
                      //               maxZoomLevel: 14,
                      //               stepZoom: 1.0,
                      //             )),
                      //       )
                      //     : SizedBox(),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        const Padding(
          padding: EdgeInsets.fromLTRB(6, 40, 0, 0),
          child: CircleAvatar(
            radius: 25,
            backgroundColor: Colors.blue,
            child: Icon(
              Icons.event_available,
              color: Colors.white,
            ),
          ),
        ),
      ],
    );
  }
}

class SingleText extends StatelessWidget {
  SingleText({
    Key? key,
    required this.subtitle,
    required this.title,
    this.isAddress = false,
  }) : super(key: key);

  String subtitle;
  bool isAddress;

  String title;
  // bool? isTitle;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 150,
            child: Text(
              '$title :',
              style: const TextStyle(color: Colors.black),
            ),
          ),
          SizedBox(
            width: 100,
            child: Text(
              subtitle,
              style: const TextStyle(color: Colors.black),
            ),
          ),
        ],
      ),
    );
  }
}

class CustomButton extends StatelessWidget {
  double height;
  double width;
  Color btnColor;
  String text;
  CustomButton(
      {super.key,
      required this.btnColor,
      required this.height,
      required this.text,
      required this.width});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width,
      height: height,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        color: btnColor,
        border: Border.all(
          width: 2,
        ),
      ),
      child: Center(
        child: FittedBox(
          fit: BoxFit.fitWidth,
          child: Text(
            text,
          ),
        ),
      ),
    );
  }
}
