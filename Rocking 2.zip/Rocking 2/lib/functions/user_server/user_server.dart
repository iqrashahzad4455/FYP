import 'dart:developer';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:provider/provider.dart';
import 'package:rockingequestrian/database/user_database.dart';
import 'package:rockingequestrian/functions/models/notification_model.dart';
import 'package:rockingequestrian/functions/models/user_model.dart';
import 'package:rockingequestrian/provider/user_provider.dart';
import 'package:rockingequestrian/types/login_response.dart';

import '../../types/signup_response.dart';

@immutable
class UserServer {
  /// Contains Firestore user collection name
  static const String userCollection = "users";

  /// Contains Firestore notification collection name
  static const String notificationCollection = "notifications";

  /// Provide a instance to User collection firestore instance
  CollectionReference<Map<String, dynamic>> get instance {
    return FirebaseFirestore.instance.collection(userCollection);
  }

  /// Get user by Id as Stream
  Stream<UserModel> getUserById(String id) {
    return instance.doc(id).snapshots().map<UserModel>(
      (DocumentSnapshot<Map<String, dynamic>> e) {
        return UserModel.fromMap(e.data() ?? <String, dynamic>{});
      },
    );
  }

  /// Get user by Id as Stream
  Future<void> updateUser({
    required String id,
    required UserModel model,
  }) {
    return instance.doc(id).update(model.toFirestore());
  }

  Future<SignupResponse> signupUser({required UserModel user}) async {
    try {
      /// Check if user has an account or he is a fresher
      final DocumentSnapshot<Map<String, dynamic>> result =
          await instance.doc(user.email).get();
      // Check result has any document details or not
      if (result.exists ||
          (result.data() != null && result.data()!.isNotEmpty)) {
        return SignupResponse.alreadyExists;
      }
      // create user account in database
      await instance.doc(user.email).set(user.toFirestore());
      // user account is created
      return SignupResponse.success;
    } catch (e) {
      if (kDebugMode) {
        log("signupUser Error: ${e.toString()}");
      }
    }
    return SignupResponse.error;
  }

  /// Create an Instance of `UserDatabase`
  final UserDatabase _userDatabase = UserDatabase.instance;

  Future<LoginResponse> login({
    required String email,
    required String password,
  }) async {
    try {
      /// Check if user has an account or not
      final DocumentSnapshot<Map<String, dynamic>> result =
          await instance.doc(email).get();
      // Check result has any document details or not
      if (result.exists ||
          (result.data() != null && result.data()!.isNotEmpty)) {
        if ((result.data()?['password'] ?? "") == password) {
          await _userDatabase.storeUserDetails(uid: email, pwd: password);
          await _userDatabase.storeName(
            name: result.data()?['name'] ?? "",
          );

          return LoginResponse.success;
        } else {
          return LoginResponse.incorrectPassword;
        }
      } else {
        return LoginResponse.doesnotExists;
      }
    } catch (e) {
      if (kDebugMode) {
        log("login Error: ${e.toString()}");
      }
    }
    return LoginResponse.error;
  }

  /// Get user by Id as Stream
  Future<bool> follow({
    required UserModel user,
    required BuildContext context,
  }) {
    try {
      // Create an Instance of `UserProvider`
      final UserProvider provider = context.read<UserProvider>();
      // Create Signin User following list
      final List<String> followings = provider.user.followingList;
      // add a new user into following list
      followings.add(user.email);
      // update signin user into database
      instance.doc(_userDatabase.getUID).update(
          provider.user.copyWith(followingList: followings).toFirestore());
      // Create User followers list
      final List<String> followers = user.followersList;
      // add singin user into followers list
      followers.add(_userDatabase.getUID ?? "");
      // send notification the user
      storeNotification(
        userId: user.email,
        notification: NotificationModel(
          name: provider.user.name,
          title: "New Follower",
          userProfileUrl: provider.user.profileUrl,
        ),
      );
      return instance
          .doc(user.email)
          .update(user.copyWith(followersList: followers).toFirestore())
          .then<bool>((_) => true);
    } catch (e) {
      if (kDebugMode) {
        log("follow Error: ${e.toString()}");
      }
    }
    return Future<bool>.value(false);
  }

  /// Get user by Id as Stream
  Future<bool> unFollow({
    required UserModel user,
    required BuildContext context,
  }) {
    try {
      // Create an Instance of `UserProvider`
      final UserProvider provider = context.read<UserProvider>();
      // Create Signin User following list
      final List<String> followings = provider.user.followingList;
      // add a new user into following list
      followings.removeWhere((String e) => e == user.email);
      // update signin user into database
      instance.doc(_userDatabase.getUID).update(
          provider.user.copyWith(followingList: followings).toFirestore());
      // Create User followers list
      final List<String> followers = user.followersList;
      // add singin user into followers list
      followers.removeWhere((String e) => e == (_userDatabase.getUID ?? ""));
      return instance
          .doc(user.email)
          .update(user.copyWith(followersList: followers).toFirestore())
          .then<bool>((_) => true);
    } catch (e) {
      if (kDebugMode) {
        log("unFollow Error: ${e.toString()}");
      }
    }
    return Future<bool>.value(false);
  }

  /// Store notification to provided user list
  Future<void> storeNotification({
    required String userId,
    required NotificationModel notification,
  }) {
    try {
      return instance
          .doc(userId)
          .collection(notificationCollection)
          .add(notification.toFirestore());
    } catch (e) {
      if (kDebugMode) {
        log("storeNotification Error: ${e.toString()}");
      }
      return Future<void>.value();
    }
  }

  /// Get notification to provided user list
  Stream<List<NotificationModel>> getNotificationsById(String userId) {
    try {
      return instance
          .doc(userId)
          .collection(notificationCollection)
          .snapshots()
          .map((QuerySnapshot<Map<String, dynamic>> result) {
        return List<NotificationModel>.from(
          result.docs.map<NotificationModel>(
              (QueryDocumentSnapshot<Map<String, dynamic>> e) {
            return NotificationModel.fromFirestore(e.data());
          }),
        );
      });
    } catch (e) {
      if (kDebugMode) {
        log("getNotificationsById Error: ${e.toString()}");
      }
      return Stream<List<NotificationModel>>.value(<NotificationModel>[]);
    }
  }
}
