import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:rockingequestrian/functions/extensions/string/string.extensions.fucntions.dart';
import 'package:rockingequestrian/types/user_type.dart';

@immutable
class PostModel {
  final String? userID;
  final String? postID;
  final String? postBy;
  final String? content;
  final UserTypes? userType;
  final List<String>? media;
  final Timestamp? createdAt;
  final Timestamp? updatedAt;
  final Timestamp? addcomment;
  final List<String>? likesID;

  const PostModel({
    this.media,
    this.userID,
    this.postID,
    this.postBy,
    this.content,
    this.likesID,
    this.userType,
    this.createdAt,
    this.updatedAt,
    this.addcomment,
  });

  @override
  bool operator ==(covariant PostModel other) {
    if (identical(this, other)) return true;

    return other.likesID == likesID &&
        other.media == media &&
        other.userID == userID &&
        other.postID == postID &&
        other.postBy == postBy &&
        other.content == content &&
        other.userType == userType &&
        other.createdAt == createdAt &&
        other.updatedAt == updatedAt;
  }

  @override
  int get hashCode {
    return likesID.hashCode ^
        media.hashCode ^
        userID.hashCode ^
        postID.hashCode ^
        postBy.hashCode ^
        content.hashCode ^
        userType.hashCode ^
        createdAt.hashCode ^
        updatedAt.hashCode;
  }

  @override
  String toString() {
    return 'PostModel(likesID: $likesID, media: $media, userID: $userID, postID: $postID, postBy: $postBy, content: $content, userType: $userType,createdAt: $createdAt, updatedAt: $updatedAt)';
  }

  PostModel copyWith({
    String? userID,
    String? postBy,
    String? content,
    List<String>? media,
    UserTypes? userType,
    Timestamp? createdAt,
    Timestamp? updatedAt,
    List<String>? likesID,
  }) {
    return PostModel(
      likesID: likesID ?? this.likesID,
      media: media ?? this.media,
      userID: userID ?? this.userID,
      postBy: postBy ?? this.postBy,
      content: content ?? this.content,
      userType: userType ?? this.userType,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  Map<String, dynamic> newPost() {
    return <String, dynamic>{
      'likesID': likesID,
      'media': media,
      'userID': userID,
      'postBy': postBy,
      'content': content,
      'userType': userType?.name,
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': updatedAt,
    };
  }

  Map<String, dynamic> updatePost() {
    return <String, dynamic>{
      'media': media,
      'userID': userID,
      'postBy': postBy,
      'likesID': likesID,
      'content': content,
      'createdAt': createdAt,
      'userType': userType?.name,
      'updatedAt': FieldValue.serverTimestamp(),
    };
  }

  factory PostModel.fromMap(DocumentSnapshot<Map<String, dynamic>> map) {
    return PostModel(
      postID: map.id,
      userID: map.data()?['userID'] as String?,
      postBy: map.data()?['postBy'] as String?,
      content: map.data()?['content'] as String?,
      createdAt: map.data()?['createdAt'] as Timestamp?,
      updatedAt: map.data()?['updatedAt'] as Timestamp?,
      media: map.data()?['media'] != null
          ? List<String>.from(
              ((map.data()?['media'] as List?) ?? <String>[]).map<String>(
                (e) => e.toString(),
              ),
            )
          : null,
      likesID: map.data()?['likesID'] != null
          ? List<String>.from(
              ((map.data()?['likesID'] as List?) ?? <String>[]).map<String>(
                (e) => e.toString(),
              ),
            )
          : null,
      userType: UserTypes.values
          .toList()
          .firstWhere(orElse: () => UserTypes.none, (UserTypes e) {
        if (map.data()?['userType'] != null) {
          return e.name.isSame(map.data()!['userType'].toString());
        }
        return false;
      }),
    );
  }
}
