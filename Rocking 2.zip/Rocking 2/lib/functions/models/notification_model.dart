import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

@immutable
class NotificationModel {
  final String name;
  final String title;
  final Timestamp? time;
  final String? userProfileUrl;

  const NotificationModel({
    this.time,
    this.name = "",
    this.title = "",
    this.userProfileUrl,
  });

  @override
  bool operator ==(covariant NotificationModel other) {
    if (identical(this, other)) return true;

    return other.name == name &&
        other.title == title &&
        other.time == time &&
        other.userProfileUrl == userProfileUrl;
  }

  @override
  int get hashCode {
    return name.hashCode ^
        title.hashCode ^
        time.hashCode ^
        userProfileUrl.hashCode;
  }

  @override
  String toString() {
    return 'NotificationModel(name: $name, title: $title, time: $time, userProfileUrl: $userProfileUrl)';
  }

  Map<String, dynamic> toFirestore() {
    return <String, dynamic>{
      'name': name,
      'title': title,
      'userProfileUrl': userProfileUrl,
      'time': FieldValue.serverTimestamp(),
    };
  }

  factory NotificationModel.fromFirestore(Map<String, dynamic> map) {
    return NotificationModel(
      name: (map['name'] as String?) ?? "",
      title: (map['title'] as String?) ?? "",
      time: map['time'] != null ? map['time'] as Timestamp? : null,
      userProfileUrl: map['userProfileUrl'] != null
          ? map['userProfileUrl'] as String
          : null,
    );
  }
}
