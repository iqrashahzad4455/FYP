import 'package:flutter/foundation.dart';

@immutable
class UserModel {
  final String dOB;
  final String type;
  final String name;
  final String like;
  final String? bio;
  final String email;
  final String dislike;
  final String password;
  final String? profileUrl;
  final List<String> followersList;
  final List<String> followingList;

  const UserModel({
    this.bio,
    this.dOB = "",
    this.name = "",
    this.like = "",
    this.type = "",
    this.email = "",
    this.profileUrl,
    this.dislike = "",
    this.password = "",
    this.followersList = const <String>[],
    this.followingList = const <String>[],
  });

  /// When user want to signup
  Map<String, dynamic> toFirestore() {
    return <String, dynamic>{
      'bio': bio,
      'dOB': dOB,
      'type': type,
      'like': like,
      'name': name,
      'email': email,
      'dislike': dislike,
      'password': password,
      'profileUrl': profileUrl,
      'followersList': followersList,
      'followingList': followingList,
    };
  }

  factory UserModel.fromMap(Map<String, dynamic> map) {
    return UserModel(
      bio: map['bio'],
      name: map['name'] as String,
      email: map['email'] as String,
      dOB: map['dOB'] as String,
      type: map['type'] as String,
      profileUrl: map['profileUrl'],
      password: map['password'] as String,
      followersList: map['followersList'] != null
          ? List<String>.from(
              map['followersList'].map<String>((e) => e.toString()),
            )
          : <String>[],
      followingList: map['followingList'] != null
          ? List<String>.from(
              map['followingList'].map<String>((e) => e.toString()),
            )
          : <String>[],
    );
  }

  @override
  bool operator ==(covariant UserModel other) {
    if (identical(this, other)) return true;

    return other.dOB == dOB &&
        other.type == type &&
        other.name == name &&
        other.like == like &&
        other.bio == bio &&
        other.email == email &&
        other.dislike == dislike &&
        other.password == password &&
        other.profileUrl == profileUrl &&
        listEquals(other.followersList, followersList) &&
        listEquals(other.followingList, followingList);
  }

  @override
  int get hashCode {
    return dOB.hashCode ^
        type.hashCode ^
        name.hashCode ^
        like.hashCode ^
        bio.hashCode ^
        email.hashCode ^
        dislike.hashCode ^
        password.hashCode ^
        profileUrl.hashCode ^
        followersList.hashCode ^
        followingList.hashCode;
  }

  @override
  String toString() {
    return 'UserModel(dOB: $dOB, type: $type, name: $name, like: $like, bio: $bio, email: $email, dislike: $dislike, password: $password, profileUrl: $profileUrl, followersList: $followersList, followingList: $followingList)';
  }

  UserModel copyWith({
    String? dOB,
    String? type,
    String? name,
    String? like,
    String? bio,
    String? email,
    String? dislike,
    String? password,
    String? profileUrl,
    List<String>? followersList,
    List<String>? followingList,
  }) {
    return UserModel(
      dOB: dOB ?? this.dOB,
      type: type ?? this.type,
      name: name ?? this.name,
      like: like ?? this.like,
      bio: bio ?? this.bio,
      email: email ?? this.email,
      dislike: dislike ?? this.dislike,
      password: password ?? this.password,
      profileUrl: profileUrl ?? this.profileUrl,
      followersList: followersList ?? this.followersList,
      followingList: followingList ?? this.followingList,
    );
  }
}
