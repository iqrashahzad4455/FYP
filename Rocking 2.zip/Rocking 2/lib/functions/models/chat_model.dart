import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

@immutable
class ChatModel {
  final Timestamp? time;
  final String message;
  final String receiverID;
  final String senderID;
  final String sentBy;
  final String userID1;
  final String userID2;
  final String id;
  final String? imageMessageUrl;

  const ChatModel({
    this.time,
    this.id = "",
    this.message = "",
    this.receiverID = "",
    this.senderID = "",
    this.sentBy = "",
    this.userID1 = "",
    this.userID2 = "",
    this.imageMessageUrl,
  });

  /// When user want to signup
  Map<String, dynamic> toFirestore() {
    return <String, dynamic>{
      'message': message,
      'receiver_id': receiverID,
      'send_id': senderID,
      'sent_by': sentBy,
      'user_id_1': userID1,
      'user_id_2': userID2,
      'message_time': FieldValue.serverTimestamp(),
    };
  }

  factory ChatModel.fromMap(QueryDocumentSnapshot<Map<String, dynamic>> map) {
    return ChatModel(
      id: map.id,
      time: map.data()['message_time'] as Timestamp?,
      sentBy: (map.data()['sent_by'] as String?) ?? "",
      message: (map.data()['message'] as String?) ?? "",
      senderID: (map.data()['send_id'] as String?) ?? "",
      userID1: (map.data()['user_id_1'] as String?) ?? "",
      userID2: (map.data()['user_id_2'] as String?) ?? "",
      receiverID: (map.data()['receiver_id'] as String?) ?? "",
    );
  }

  @override
  bool operator ==(covariant ChatModel other) {
    if (identical(this, other)) return true;

    return other.time == time &&
        other.message == message &&
        other.receiverID == receiverID &&
        other.senderID == senderID &&
        other.sentBy == sentBy &&
        other.userID1 == userID1 &&
        other.userID2 == userID2 &&
        other.id == id;
  }

  @override
  int get hashCode {
    return time.hashCode ^
        message.hashCode ^
        receiverID.hashCode ^
        senderID.hashCode ^
        sentBy.hashCode ^
        userID1.hashCode ^
        userID2.hashCode ^
        id.hashCode;
  }

  @override
  String toString() {
    return 'ChatModel(time: $time, message: $message, receiverID: $receiverID, senderID: $senderID, sentBy: $sentBy, userID1: $userID1, userID2: $userID2, id: $id)';
  }
}
