import 'dart:async';
import 'dart:developer';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:rockingequestrian/database/user_database.dart';
import 'package:rockingequestrian/functions/models/chat_model.dart';
import 'package:rockingequestrian/functions/models/notification_model.dart';
import 'package:rockingequestrian/functions/models/user_model.dart';
import 'package:rxdart/rxdart.dart';
import '../user_server/user_server.dart';

@immutable
class ChatServer {
  final FirebaseFirestore firestore;
  final UserDatabase userDatabase;
  const ChatServer({
    required this.firestore,
    required this.userDatabase,
  });

  /// Contains Firestore chats collection name
  static const String chatsCollection = "chats";

  Future<void> sendMessage({
    required String message,
    required String receiverID,
  }) async {
    await firestore.collection(chatsCollection).add({
      "message": message,
      "user_id_1": userDatabase.getUID,
      "user_id_2": receiverID,
      "receiver_id": receiverID,
      "send_id": userDatabase.getUID,
      "sent_by": userDatabase.getUID,
      "message_time": FieldValue.serverTimestamp(),
    });
    return;
  }

  Future<List<ChatModel>> getMessages({
    required String userId1,
  }) async {
    final List<ChatModel> result = await firestore
        .collection(chatsCollection)
        .where("user_id_1", isEqualTo: userId1)
        .where("user_id_2", isEqualTo: userDatabase.getUID)
        .get()
        .then((QuerySnapshot<Map<String, dynamic>> value) {
      if (value.docs.isNotEmpty) {
        return value.docs.map((e) => ChatModel.fromMap(e)).toList();
      } else {
        return <ChatModel>[];
      }
    });
    // Check if Result is empty then apply second condition
    if (result.isNotEmpty) {
      return result;
    } else {
      return await firestore
          .collection(chatsCollection)
          .where("user_id_1", isEqualTo: userDatabase.getUID)
          .where("user_id_2", isEqualTo: userId1)
          .get()
          .then((QuerySnapshot<Map<String, dynamic>> value) {
        if (value.docs.isNotEmpty) {
          return value.docs.map((e) => ChatModel.fromMap(e)).toList();
        } else {
          return <ChatModel>[];
        }
      });
    }
  }

  Stream<List<ChatModel>> getMessagesStream({required String userId1}) {
    return Rx.combineLatest2<List<ChatModel>, List<ChatModel>, List<ChatModel>>(
      _getMessagesStreamGroup1(userId1: userId1),
      _getMessagesStreamGroup2(userId1: userId1),
      (List<ChatModel> msg1, List<ChatModel> msg2) {
        final List<ChatModel> merged = <ChatModel>[...msg1, ...msg2];
        merged.sort((ChatModel a, ChatModel b) {
          final DateTime t = DateTime.now();
          return (b.time?.toDate() ?? t).compareTo(a.time?.toDate() ?? t);
        });
        return merged;
      },
    );
  }

  Stream<List<ChatModel>> _getMessagesStreamGroup1({required String userId1}) {
    return firestore
        .collection(chatsCollection)
        .where("user_id_1", isEqualTo: userId1)
        .where("user_id_2", isEqualTo: userDatabase.getUID)
        .orderBy("message_time", descending: true)
        .snapshots()
        .map((QuerySnapshot<Map<String, dynamic>> result) {
      log("_getMessagesStreamGroup1 ${result.docs.length}");
      if (result.docs.isNotEmpty) {
        return result.docs.map((e) => ChatModel.fromMap(e)).toList();
      } else {
        return <ChatModel>[];
      }
    });
  }

  Stream<List<ChatModel>> _getMessagesStreamGroup2({required String userId1}) {
    return firestore
        .collection(chatsCollection)
        .where("user_id_1", isEqualTo: userDatabase.getUID)
        .where("user_id_2", isEqualTo: userId1)
        .orderBy("message_time", descending: true)
        .snapshots()
        .map((QuerySnapshot<Map<String, dynamic>> result) {
      log("_getMessagesStreamGroup2 ${result.docs.length}");
      if (result.docs.isNotEmpty) {
        return result.docs.map((e) => ChatModel.fromMap(e)).toList();
      } else {
        return <ChatModel>[];
      }
    });
  }

  Future<List<UserModel>> getUsers() {
    return firestore
        .collection(UserServer.userCollection)
        .get()
        .then((QuerySnapshot<Map<String, dynamic>> r) {
      if (r.docs.isEmpty) {
        return <UserModel>[];
      } else {
        return r.docs.map((e) => UserModel.fromMap(e.data())).toList();
      }
    });
  }

  Future<void> deleteUserChat({required String userId1}) async {
    // First Get User Chat History Then Delete All Messages
    await firestore
        .collection(chatsCollection)
        .where("user_id_1", isEqualTo: userDatabase.getUID)
        .where("user_id_2", isEqualTo: userId1)
        .get()
        .then<void>((QuerySnapshot<Map<String, dynamic>> res) async {
      // Check if result is not empty then start deleting messages
      if (res.docs.isNotEmpty) {
        // Start a loop and delete meessages one by one
        for (QueryDocumentSnapshot<Map<String, dynamic>> doc in res.docs) {
          // Delete Message
          await deleteSingleMessage(doc.id);
        }
      }
      // Close this function
      return;
    });

    /// Delete Recieved Messages
    return await firestore
        .collection(chatsCollection)
        .where("user_id_1", isEqualTo: userDatabase.getUID)
        .where("user_id_2", isEqualTo: userId1)
        .get()
        .then<void>((QuerySnapshot<Map<String, dynamic>> res) async {
      // Check if result is not empty then start deleting messages
      if (res.docs.isNotEmpty) {
        // Start a loop and delete meessages one by one
        for (QueryDocumentSnapshot<Map<String, dynamic>> doc in res.docs) {
          // Delete Message
          await deleteSingleMessage(doc.id);
        }
      }
      // Close this function
      return;
    });
  }

  /// Delete Single Message Based on Provided Document Id
  Future<void> deleteSingleMessage(String id) {
    return firestore.collection(chatsCollection).doc(id).delete();
  }
}
