import 'dart:io';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:rockingequestrian/utils/image_picker_utils.dart';

@immutable
class UploaderStorage {
  Future<String?> uploadMedia(File file) async {
    try {
      final Reference i =
          _s.ref(docName).child(ImagePickerUtils.instance.fileName(file));
      final UploadTask t = i.putFile(File(file.path));
      return await (await t).ref.getDownloadURL();
    } catch (e) {
      return null;
    }
  }

  Future<String?> uploadProfile(File file) async {
    try {
      final Reference i =
          _s.ref(profilePic).child(ImagePickerUtils.instance.fileName(file));
      final UploadTask t = i.putFile(File(file.path));
      return await (await t).ref.getDownloadURL();
    } catch (e) {
      return null;
    }
  }

  Future<String?> uploadProduct(File file) async {
    try {
      final Reference i =
          _s.ref(product).child(ImagePickerUtils.instance.fileName(file));
      final UploadTask t = i.putFile(File(file.path));
      return await (await t).ref.getDownloadURL();
    } catch (e) {
      return null;
    }
  }

  /// Contains Directory Name
  final String docName = "rocking_community";

  /// Contains Directory Name
  final String product = "rocking_product";

  /// Contains Directory Name
  final String profilePic = "profile_pics";

  /// `FirebaseStorage` Instance
  final FirebaseStorage _s = FirebaseStorage.instance;

  Future<void> delete(String path) async {
    try {
      final Reference instance = _s.refFromURL(path);
      return await instance.delete();
    } catch (e) {
      return;
    }
  }
}
