import 'dart:developer';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:rockingequestrian/functions/models/post_model.dart';

@immutable
class PostServer {
  /// Create An Instance of Database Collection
  static const String postCollection = "posts";

  /// Provide a instance to Post collection firestore instance
  CollectionReference<Map<String, dynamic>> get instance {
    return FirebaseFirestore.instance.collection(postCollection);
  }

  /// Add `Post` into `Database`
  Future<bool> addPost(PostModel model) {
    try {
      return instance.add(model.newPost()).then<bool>((_) => true);
    } catch (e) {
      // Print Details in Debug Console
      if (kDebugMode) {
        log("PostServer addPost Error: ${e.toString()}");
      }
      // return false
      return Future<bool>.value(false);
    }
  }

  /// Add `Post` into `Database`
  Stream<List<PostModel>> getPosts() {
    try {
      return instance
          .orderBy("createdAt", descending: true)
          .snapshots()
          .map<List<PostModel>>((QuerySnapshot<Map<String, dynamic>> result) {
        return List<PostModel>.from(result.docs
            .map<PostModel>((QueryDocumentSnapshot<Map<String, dynamic>> e) {
          return PostModel.fromMap(e);
        }));
      });
    } catch (e) {
      // Print Details in Debug Console
      if (kDebugMode) {
        log("PostServer getPosts Error: ${e.toString()}");
      }
      // return Empty List
      return Stream<List<PostModel>>.value(<PostModel>[]);
    }
  }

  /// Delete `Post` from `Database`
  Future<bool> deletePost(PostModel model) {
    try {
      return instance.doc(model.postID).delete().then<bool>((_) => true);
    } catch (e) {
      // Print Details in Debug Console
      if (kDebugMode) {
        log("PostServer deletePost Error: ${e.toString()}");
      }
      // return false
      return Future<bool>.value(false);
    }
  }

  /// Add `Post` into `Database`
  Stream<List<PostModel>> getPostsByUser(String id) {
    try {
      return instance
          .where("userID", isEqualTo: id)
          .orderBy("createdAt", descending: true)
          .snapshots()
          .map<List<PostModel>>((QuerySnapshot<Map<String, dynamic>> result) {
        return List<PostModel>.from(result.docs
            .map<PostModel>((QueryDocumentSnapshot<Map<String, dynamic>> e) {
          return PostModel.fromMap(e);
        }));
      });
    } catch (e) {
      // Print Details in Debug Console
      if (kDebugMode) {
        log("PostServer getPostsByUser Error: ${e.toString()}");
      }
      // return Empty List
      return Stream<List<PostModel>>.value(<PostModel>[]);
    }
  }
}
