import 'package:flutter/material.dart';
import 'package:rockingequestrian/utils/snackbar_utils.dart';

/// Provide Extra Fucntions on String
extension StringExetendedFeatures on String? {
  String get nullSafe => this ?? "";
  bool get isEmpty => nullSafe.isEmpty;
  bool get isNotEmpty => nullSafe.isNotEmpty;
  bool isSame(String i) => i.toLowerCase() == nullSafe.toLowerCase();

  void snackbar(BuildContext context) {
    return showSnackbar(message: nullSafe, context: context);
  }
}
